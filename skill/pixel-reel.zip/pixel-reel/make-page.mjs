#!/usr/bin/env node
// Checks a pixel reel and makes it into one web page: node make-page.mjs reel.json [page.html]
// Made by npm run skill in the pixelreel project from the player's own checks: do not edit.
import { readFileSync, writeFileSync } from 'node:fs';
import { basename, dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
const __m = {};

__m['pictures.js'] = (() => {
// Ready-made pictures: a scene can say picture: { type: 'list', items: [...] } instead of
// writing draw(t, px). Each one animates in time with the scene. Data only, so a script or
// an AI agent can write a whole reel without a line of drawing code.

const INK = '#1a1a1a', NIGHT = '#0b1220', NAVY = '#13203a', CREAM = '#ebeac5', LIGHT = '#fdf6e3', GOLD = '#ffcc4d';
const TEAL = '#55d6be', BLUE = '#24476b', GREY = '#9fb3c8', PINK = '#ff7eb6', MUTED = '#6f87a3';

/** Shrinks `size` (in steps of 2) until `str` fits in `maxW`. */
function fit(px, str, size, maxW, min = 10) {
  while (size > min && px.textW(str, size) > maxW) size -= 2;
  return size;
}

/** A panel with its corners knocked off, the way pixel art rounds things. */
function roundBox(px, x, y, w, h, fill, edge = INK) {
  px.rect(edge, x + 1, y, w - 2, h);
  px.rect(edge, x, y + 1, w, h - 2);
  px.rect(fill, x + 1, y + 1, w - 2, h - 2);
}

/** The three coloured dots on a window's title bar. */
function dots(px, x, y) {
  ['#d63a3a', GOLD, '#3fa34d'].forEach((c, i) => px.rect(c, x + i * 6, y, 4, 4));
}

/** A window with a title bar; returns the inside: { x, y, w, h }. */
function frame(px, x, y, w, h, title, body) {
  px.window(x, y, w, h, body);
  px.rect(BLUE, x + 1, y + 1, w - 2, 12);
  dots(px, x + 5, y + 5);
  if (title) px.text(title, x + w / 2, y + 1, 12, CREAM, 'center');
  return { x: x + 1, y: y + 13, w: w - 2, h: h - 14 };
}

/** Wrapped text, centred on cx, typed out line by line from `start`. */
function typedBlock(px, str, cx, y, t, start, size, col, maxW, cps = 28) {
  let budget = Math.floor((t - start) * cps);
  px.wrap(str, maxW, size).forEach((line, i) => {
    const shown = line.slice(0, Math.max(0, budget));
    budget -= line.length;
    if (shown) px.text(shown, Math.round(cx - px.textW(line, size) / 2), y + i * (size + 3), size, col);
  });
}

const memos = new WeakMap();

/** Works something out once per picture (layouts need the font, so they wait for the first frame). */
function memo(p, key, fn) {
  if (!memos.has(p)) memos.set(p, {});
  const m = memos.get(p);
  if (!(key in m)) m[key] = fn();
  return m[key];
}

/** The biggest of `sizes` at which every line fits `maxW` and `rowsFor(size)` rows fit. */
function fitLines(px, lines, sizes, maxW, rowsFor, rowsNeeded) {
  return sizes.find((s) => rowsFor(s) >= rowsNeeded && lines.every((l) => px.textW(l, s) <= maxW)) ?? sizes.at(-1);
}

function title(t, px, p) {
  const { W } = px;
  px.sky(NIGHT, '#2f5d8a');
  px.stars(t);
  px.moon(278, 28);
  px.hills('#1f3b5e', 152, 26, t * 3, 2);
  px.hills('#142a45', 170, 14, t * 8, 5);
  const size = fit(px, p.text, 36, W - 36);
  const y = Math.round(px.tween(t, 0.15, 1, -50, p.sub ? 44 : 64, 'bounce'));
  px.text(p.text, W / 2, y + 2, size, INK, 'center');
  px.text(p.text, W / 2, y, size, GOLD, 'center', '#7a4a24');
  if (p.sub) typedBlock(px, p.sub, W / 2, y + size + 8, t, 1.3, 14, LIGHT, W - 60);
}

const TICK = ['.........g', '........gg', 'g......gg.', 'gg....gg..', '.gg..gg...', '..gggg....', '...gg.....'];

function list(t, px, p) {
  const { W, H } = px;
  px.rect(NAVY, 0, 0, W, H);
  for (let y = 4; y < H; y += 8) for (let x = 4; x < W; x += 8) px.rect('#1a2b47', x, y, 1, 1);
  const top = p.heading ? 36 : 10, room = H - top - 8;
  if (p.heading) px.sign(p.heading, W / 2, 9, fit(px, p.heading, 16, W - 40), GOLD);
  const n = p.items.length, rowH = Math.min(30, Math.floor(room / n));
  const size = Math.max(10, Math.min(20, rowH - 8) & ~1);
  const first = top + Math.floor((room - rowH * n) / 2);   // the list sits in the middle of the space left
  const every = p.every ?? 1.4, start = p.start ?? 0.6;
  const latest = Math.floor((t - start) / every);
  p.items.forEach((item, i) => {
    const at = start + i * every;
    if (t < at) return;
    const x = 26 + Math.round(px.tween(t, at, 0.35, -70, 0, 'out'));
    const y = first + i * rowH + Math.floor((rowH - 13) / 2);
    if (p.numbered) {
      px.circle(GOLD, x + 6, y + 6, 7);
      px.text(String(i + 1), x + 6, y, 12, INK, 'center');
    } else {
      px.window(x, y, 13, 13, LIGHT);
      if (t >= at + 0.3) px.sprite(TICK, x + 2, y + 3);
    }
    const s = fit(px, item, size, W - x - 30);
    px.text(item, x + 20, y + 7 - Math.round(s * 0.55), s, i === latest && t < at + every + 1 ? GOLD : CREAM, 'left', INK);
  });
}

const CMD_CPS = 16;

/** When each terminal line starts and finishes: commands (lines starting "$ ") type, output appears. */
function terminalPlan(lines) {
  let at = 0.6;
  return lines.map((line) => {
    const cmd = line.startsWith('$ ');
    const text = cmd ? line.slice(2) : line;
    const start = at, end = cmd ? start + text.length / CMD_CPS : start;
    at = cmd ? end + 0.45 : start + 0.18;
    return { text, cmd, start, end };
  });
}

function terminal(t, px, p) {
  const { W, H } = px;
  px.rect(NIGHT, 0, 0, W, H);
  const box = frame(px, 14, 10, W - 28, H - 20, p.title ?? 'terminal', '#0d1117');
  const plan = terminalPlan(p.lines);
  const size = memo(p, 'size', () => fitLines(px, p.lines.map((l) => '  ' + l), [16, 14, 12], box.w - 16, (s) => Math.floor((box.h - 8) / (s + 1)), p.lines.length + 1));
  const rowH = size + 1, rows = Math.floor((box.h - 8) / rowH), indent = Math.round(size * 0.75), caret = Math.round(size * 0.75);
  const done = plan.length && t >= plan.at(-1).end + 0.4;
  const shown = plan.filter((l) => t >= l.start);
  const visible = shown.slice(-(done ? rows - 1 : rows));
  visible.forEach((l, i) => {
    const y = box.y + 5 + i * rowH;
    if (!l.cmd) { px.text(l.text, box.x + 6, y, size, GREY); return; }
    px.text('$', box.x + 6, y, size, TEAL);
    const typing = t < l.end;
    const text = typing ? px.typed(l.text, t, l.start, CMD_CPS) : l.text;
    px.text(text, box.x + 6 + indent, y, size, LIGHT);
    if (typing) px.rect(LIGHT, box.x + 7 + indent + px.textW(text, size), y + 2, Math.round(size / 3), caret);
  });
  if (done) {
    const y = box.y + 5 + visible.length * rowH;
    px.text('$', box.x + 6, y, size, TEAL);
    if (px.blink(t, 1)) px.rect(LIGHT, box.x + 7 + indent, y + 2, Math.round(size / 3), caret);
  }
}

const KEYWORDS = new Set(['export', 'default', 'import', 'from', 'const', 'let', 'var', 'function', 'return', 'if', 'else',
  'for', 'while', 'new', 'true', 'false', 'null', 'undefined', 'async', 'await', 'class', 'this', 'of', 'in']);

/** Splits a line of code into [text, colour] pieces, for simple highlighting. */
function highlight(line) {
  const out = [];
  const re = /(\/\/.*$|#.*$)|('(?:[^'\\]|\\.)*'?|"(?:[^"\\]|\\.)*"?|`(?:[^`\\]|\\.)*`?)|(\b\d+(?:\.\d+)?\b)|([A-Za-z_$][\w$]*)|(\s+)|([\s\S])/g;
  let m;
  while ((m = re.exec(line))) {
    let c = CREAM;
    if (m[1]) c = MUTED;
    else if (m[2]) c = GOLD;
    else if (m[3]) c = TEAL;
    else if (m[4]) c = KEYWORDS.has(m[4]) ? PINK : /^\s*:/.test(line.slice(re.lastIndex)) ? '#8fd3ff' : CREAM;
    else if (m[6]) c = GREY;
    out.push([m[0], c]);
  }
  return out;
}

const CODE_CPS = 40;

function code(t, px, p) {
  const { W, H } = px;
  px.rect(NIGHT, 0, 0, W, H);
  const box = frame(px, 14, 10, W - 28, H - 20, p.title ?? 'reel.js', '#101a2c');
  const gutter = 22;
  const size = memo(p, 'size', () => fitLines(px, p.lines, [14, 12, 10], box.w - gutter - 12, (s) => Math.floor((box.h - 6) / s), p.lines.length));
  const rowH = size, rows = Math.floor((box.h - 6) / rowH);
  px.rect('#0c1424', box.x, box.y, gutter, box.h);
  let budget = Math.floor((t - 0.5) * CODE_CPS), started = 0;
  const shown = p.lines.map((line) => {
    if (budget >= 0) started++;
    const part = line.slice(0, Math.max(0, budget));
    budget -= line.length + 4;   // a beat at the end of each line
    return part;
  });
  const first = Math.max(0, started - rows);
  for (let i = first; i < Math.min(started, first + rows); i++) {
    const y = box.y + 4 + (i - first) * rowH;
    px.text(String(i + 1), box.x + gutter - 4, y, Math.min(size, 12), MUTED, 'right');
    let x = box.x + gutter + 6;
    for (const [piece, c] of highlight(shown[i])) { px.text(piece, x, y, size, c); x += px.textW(piece, size); }
    if (shown[i].length < p.lines[i].length && i === started - 1) px.rect(LIGHT, x + 1, y + 2, Math.round(size / 3), Math.round(size * 0.75));
  }
}

/** Lays out a chat once: each message's side, lines and bubble size. */
function chatLayout(px, p) {
  const first = p.messages[0].from;
  let y = 0, last = null;
  return p.messages.map((m) => {
    const lines = px.wrap(m.text, 112, 12);
    const w = Math.max(...lines.map((l) => px.textW(l, 12))) + 10, h = lines.length * 12 + 5;
    const named = m.from !== last;
    if (named) y += last === null ? 0 : 4;
    const top = y + (named ? 11 : 0);
    y = top + h + 4;
    last = m.from;
    return { ...m, lines, w, h, named, top, bottom: y, mine: m.from !== first };
  });
}

const layouts = new WeakMap();

function chat(t, px, p) {
  const { H } = px;
  px.sky(NAVY, BLUE);
  const x = 66, y = 6, w = 188, h = H - 12;
  roundBox(px, x, y, w, h, '#f4f1de');
  px.rect(TEAL, x + 1, y + 1, w - 2, 15);
  px.rect(INK, x + 1, y + 16, w - 2, 1);
  px.text(p.title ?? p.messages[0].from, x + w / 2, y + 2, 14, INK, 'center');
  if (!layouts.has(p)) layouts.set(p, chatLayout(px, p));
  const msgs = layouts.get(p), every = p.every ?? 1.8, start = p.start ?? 0.8;
  const view = { x: x + 2, y: y + 19, w: w - 4, h: h - 22 };
  const shownCount = msgs.filter((_, i) => t >= start + i * every).length;
  const next = msgs[shownCount];
  const typing = next && t >= start + shownCount * every - 0.8;
  const bottom = (shownCount ? msgs[shownCount - 1].bottom : 0) + (typing ? 20 : 0);
  const scroll = Math.max(0, bottom - view.h + 4);
  px.clip([[view.x, view.y, view.w, view.h]], () => {
    msgs.slice(0, shownCount).forEach((m) => {
      const top = view.y + 2 + m.top - scroll;
      const bx = m.mine ? view.x + view.w - m.w - 6 : view.x + 6;
      if (m.named) px.text(m.from, m.mine ? bx + m.w : bx, top - 11, 10, MUTED, m.mine ? 'right' : 'left');
      roundBox(px, bx, top, m.w, m.h, m.mine ? TEAL : '#ffffff');
      m.lines.forEach((l, i) => px.text(l, bx + 5, top + 2 + i * 12, 12, INK));
    });
    if (typing) {
      const top = view.y + 2 + (shownCount ? msgs[shownCount - 1].bottom : 0) + 4 - scroll;
      const bx = next.mine ? view.x + view.w - 32 : view.x + 6;
      roundBox(px, bx, top, 26, 12, next.mine ? TEAL : '#ffffff');
      for (let k = 0; k < 3; k++) px.rect(MUTED, bx + 6 + k * 6, top + 5 - (Math.floor(t * 6) % 3 === k ? 1 : 0), 3, 3);
    }
  });
}

function big(t, px, p) {
  const { W, H } = px;
  px.rect('#1d1236', 0, 0, W, H);
  // squares rushing out from the middle
  for (let k = 0; k < 10; k++) {
    const r = ((k * 22 + t * 26) % 220) + 4, c = k % 2 ? '#2c1b52' : '#3a2470';
    px.rect(c, W / 2 - r, H / 2 - r, 2 * r, 6); px.rect(c, W / 2 - r, H / 2 + r - 6, 2 * r, 6);
    px.rect(c, W / 2 - r, H / 2 - r, 6, 2 * r); px.rect(c, W / 2 + r - 6, H / 2 - r, 6, 2 * r);
  }
  const size = fit(px, p.text, 48, W - 30);
  const cy = p.sub ? 58 : 72;
  const k = px.tween(t, 0.1, 0.6, 0, 1, 'back');
  if (k > 0.05) {
    px.zoom(k, W / 2, cy + size / 2, () => {
      px.text(p.text, W / 2, cy + 3, size, INK, 'center');
      px.text(p.text, W / 2, cy, size, GOLD, 'center', '#a52222');
    });
  }
  if (p.sub) typedBlock(px, p.sub, W / 2, cy + size + 10, t, 0.9, 16, LIGHT, W - 50);
}

function image(t, px, p) {
  const { W, H } = px;
  px.rect(NIGHT, 0, 0, W, H);
  const k = 1 + Math.min(t, 30) * 0.004;   // a slow push in
  px.zoom(k, W / 2, H / 2, () => px.image(p.name, 16, 12, W - 32, H - 24));
}

/**
 * Every ready-made picture: its fields (a trailing ? marks optional ones) and how it draws.
 * Kinds: text, list (of text), messages ([{ from, text }]), number, flag (true or false), image (a name from images).
 */
const PICTURES = {
  title: { fields: { text: 'text', sub: 'text?' }, draw: title },
  list: { fields: { items: 'list', heading: 'text?', numbered: 'flag?', every: 'number?', start: 'number?' }, draw: list },
  terminal: { fields: { lines: 'list', title: 'text?' }, draw: terminal },
  code: { fields: { lines: 'list', title: 'text?' }, draw: code },
  chat: { fields: { messages: 'messages', title: 'text?', every: 'number?', start: 'number?' }, draw: chat },
  big: { fields: { text: 'text', sub: 'text?' }, draw: big },
  image: { fields: { name: 'image' }, draw: image }
};

const isText = (v) => typeof v === 'string' && v.trim() !== '';
const KINDS = {
  text: [isText, 'must be text'],
  list: [(v) => Array.isArray(v) && v.length > 0 && v.every((s) => typeof s === 'string'), 'must be a list of text, for example ["One", "Two"]'],
  messages: [(v) => Array.isArray(v) && v.length > 0 && v.every((m) => m && isText(m.from) && isText(m.text)), 'must be a list of { from: "Name", text: "Hello" }'],
  number: [(v) => typeof v === 'number' && Number.isFinite(v) && v >= 0, 'must be a number of seconds'],
  flag: [(v) => typeof v === 'boolean', 'must be true or false']
};

/** Everything wrong with a scene's `picture`, as a list of messages (empty when it is fine). */
function pictureProblems(picture, imageNames = []) {
  const types = Object.keys(PICTURES);
  if (!picture || typeof picture !== 'object' || Array.isArray(picture)) return [`picture must be an object such as { type: 'title', text: 'Hello' }`];
  const spec = PICTURES[picture.type];
  if (!spec) return [`picture.type must be one of: ${types.join(', ')}`];
  const problems = [];
  const fields = Object.keys(spec.fields);
  for (const key of Object.keys(picture)) {
    if (key !== 'type' && !fields.includes(key)) problems.push(`picture: a ${picture.type} picture takes ${fields.join(', ')}, not ${key}`);
  }
  for (const [key, want] of Object.entries(spec.fields)) {
    const optional = want.endsWith('?'), kind = want.replace('?', ''), value = picture[key];
    if (value === undefined) { if (!optional) problems.push(`picture.${key} is needed for a ${picture.type} picture`); continue; }
    if (kind === 'image') {
      if (!imageNames.includes(value)) problems.push(`picture.${key} must name one of the reel's images${imageNames.length ? ` (${imageNames.join(', ')})` : ', and this reel has none'}`);
      continue;
    }
    const [ok, says] = KINDS[kind];
    if (!ok(value)) problems.push(`picture.${key} ${says}`);
  }
  return problems;
}

/** Draws ready-made picture `spec` at time `t` with pixel kit `px`. */
function drawPicture(spec, t, px) {
  const kind = PICTURES[spec?.type];
  if (!kind) throw new Error(`there is no ready-made picture called "${spec?.type}"`);
  kind.draw(t, px, spec);
}

const BARS = [CREAM, GOLD, TEAL, '#3fa34d', '#8e5bd6', '#d63a3a', BLUE];

/** The player's test card, shown when a reel will not load: colour bars, a rolling band of static and NO SIGNAL. */
function noSignal(t, px) {
  const { W, H } = px, bw = W / BARS.length, frame = Math.floor(t * 12);
  BARS.forEach((c, i) => {
    const x = Math.round(i * bw), w = Math.round((i + 1) * bw) - x;
    px.rect(c, x, 0, w, 122);
    px.rect(i % 2 ? NIGHT : BARS[BARS.length - 1 - i], x, 122, w, 14);
  });
  px.rect(NIGHT, 0, 136, W, H - 136);
  for (let i = 0; i < 4; i++) px.rect(['#05080f', NAVY, '#1a2b47', MUTED][i], 24 + i * 22, 146, 22, 24);
  const band = Math.round((t * 40) % (H + 16)) - 16;
  px.dither(LIGHT, 0, band, W, 16, 0.25);
  for (let i = 0; i < 160; i++) {
    const x = Math.floor(px.rand(frame * 997 + i) * W), y = Math.floor(px.rand(frame * 991 + i + 0.5) * H);
    px.rect(i % 3 ? LIGHT : INK, x, y, 1 + (i % 2), 1);
  }
  px.sign('NO SIGNAL', W / 2, 44, 24, NIGHT, GOLD);
  px.sign('Have you tried turning it off and on again?', W / 2, 82, 12, NIGHT, CREAM);
}

return { highlight, PICTURES, pictureProblems, drawPicture, noSignal };
})();

__m['transitions.js'] = (() => {
// Transitions: how one picture gives way to the next. Pure geometry on the grid of
// logical pixels, so the tests can check any frame without a canvas. px.transition() in
// kit.js does the drawing, both for the player between scenes and for a scene that wants
// one inside its own picture.

/** Every transition, by name. 'cut', the default, switches at once. */
const TRANSITIONS = ['cut', 'fade', 'dissolve', 'wipe', 'slide', 'blinds', 'iris', 'flash', 'star'];

const LENGTH_MS = { cut: 0, fade: 900, dissolve: 800, wipe: 700, slide: 700, blinds: 700, iris: 1100, flash: 500, star: 1000 };

/** How long a transition takes, in ms. */
function transitionMs(kind) {
  return LENGTH_MS[kind] ?? 0;
}

const clamp01 = (k) => Math.max(0, Math.min(1, k));
const easeIn = (k) => k * k * k;
const easeOut = (k) => 1 - (1 - k) ** 3;
const easeInOut = (k) => (k < 0.5 ? 4 * k * k * k : 1 - (-2 * k + 2) ** 3 / 2);
// a fixed scatter in [0, 1) for each block, the same on every frame
const scatter = (i, j) => { const v = Math.sin(i * 127.1 + j * 311.7) * 43758.5453; return v - Math.floor(v); };

/**
 * Frame `p` (0 to 1) of a transition inside `box` ({ x, y, w, h }). Returns:
 *   newAt  [dx, dy]  where to draw the incoming picture (clipped to the box)
 *   oldAt  [dx, dy]  where to draw the outgoing picture
 *   old    [[x, y, w, h], ...]  where the outgoing picture shows, over the incoming one
 *   cover  null, { colour, rects } painted solid, or { colour, level }: an ordered dither
 *          over the whole box, from 0 (none) to 1 (solid)
 */
function transitionFrame(kind, p, box) {
  p = clamp01(p);
  const { x, y, w, h } = box;
  const frame = { newAt: [0, 0], oldAt: [0, 0], old: [], cover: null };
  const whole = [[x, y, w, h]];
  switch (kind) {
    case 'fade':     // dithers down to black, then back up into the new picture
    case 'flash': {  // the same, through a white flash
      if (p < 0.5) frame.old = whole;
      frame.cover = { colour: kind === 'fade' ? '#000000' : '#fdf6e3', level: p < 0.5 ? p * 2 : (1 - p) * 2 };
      break;
    }
    case 'dissolve': {   // the old picture crumbles away in blocks
      const s = Math.max(4, Math.round(w / 40));
      for (let j = 0; j * s < h; j++) {
        for (let i = 0; i * s < w; i++) {
          if (scatter(i, j) >= p) frame.old.push([x + i * s, y + j * s, Math.min(s, w - i * s), Math.min(s, h - j * s)]);
        }
      }
      break;
    }
    case 'wipe': {   // left to right, behind a zigzag edge
      const band = Math.max(3, Math.round(h / 30));
      const edge = x - 2 * band + easeInOut(p) * (w + 2 * band);
      for (let j = 0; j * band < h; j++) {
        const tooth = j % 4 < 2 ? j % 4 : 4 - (j % 4);   // 0, 1, 2, 1, 0, ...
        const from = Math.max(x, Math.round(edge + tooth * band));
        if (from < x + w) frame.old.push([from, y + j * band, x + w - from, Math.min(band, h - j * band)]);
      }
      break;
    }
    case 'slide': {   // the new picture pushes the old one off to the left
      const shift = Math.round(easeInOut(p) * w);
      frame.newAt = [w - shift, 0];
      frame.oldAt = [-shift, 0];
      if (shift < w) frame.old = [[x, y, w - shift, h]];
      break;
    }
    case 'blinds': {   // slats close over the old picture
      const s = Math.max(4, Math.round(h / 12));
      const left = Math.round(s * (1 - easeInOut(p)));
      if (left > 0) for (let j = 0; j * s < h; j++) frame.old.push([x, y + j * s, w, Math.min(left, h - j * s)]);
      break;
    }
    case 'iris': {   // a closing circle, like the end of an old cartoon, then opening on the new picture
      const R = Math.hypot(w, h) / 2 + 1;
      let r = 0;
      if (p < 0.45) { frame.old = whole; r = R * (1 - easeIn(p / 0.45)); }
      else if (p > 0.55) r = R * easeOut((p - 0.55) / 0.45);
      frame.cover = { colour: '#000000', rects: outside(box, (row) => circleSpan(x + w / 2, y + h / 2, r, row)) };
      break;
    }
    case 'star': {   // the new picture bursts out of a spinning star. You know what you did.
      const outer = (Math.hypot(w, h) / 2) * 2.5 * easeIn(p), turn = p * 2.4;
      const points = [];
      for (let k = 0; k < 10; k++) {
        const a = turn - Math.PI / 2 + (k * Math.PI) / 5, r = k % 2 ? outer * 0.45 : outer;
        points.push([x + w / 2 + Math.cos(a) * r, y + h / 2 + Math.sin(a) * r]);
      }
      frame.old = outside(box, (row) => polygonSpans(points, row));
      break;
    }
    default:   // 'cut'
      break;
  }
  return frame;
}

/** Where the horizontal line through the middle of pixel row `row` crosses a circle: [[from, to]] or []. */
function circleSpan(cx, cy, r, row) {
  const dy = row + 0.5 - cy;
  if (Math.abs(dy) >= r) return [];
  const half = Math.sqrt(r * r - dy * dy);
  return [[cx - half, cx + half]];
}

/** The parts of pixel row `row` inside a polygon, as [[from, to], ...] (even-odd rule). */
function polygonSpans(points, row) {
  const yy = row + 0.5, xs = [];
  for (let i = 0; i < points.length; i++) {
    const [x1, y1] = points[i], [x2, y2] = points[(i + 1) % points.length];
    if ((y1 <= yy) !== (y2 <= yy)) xs.push(x1 + ((yy - y1) / (y2 - y1)) * (x2 - x1));
  }
  xs.sort((a, b) => a - b);
  const spans = [];
  for (let i = 0; i + 1 < xs.length; i += 2) spans.push([xs[i], xs[i + 1]]);
  return spans;
}

/** One-pixel-high rects covering each row of `box` outside the spans `inside(row)` returns. */
function outside(box, inside) {
  const rects = [];
  const right = box.x + box.w;
  for (let row = box.y; row < box.y + box.h; row++) {
    let at = box.x;
    for (const [from, to] of inside(row)) {
      const a = Math.max(box.x, Math.min(right, Math.round(from))), b = Math.max(box.x, Math.min(right, Math.round(to)));
      if (a > at) rects.push([at, row, a - at, 1]);
      at = Math.max(at, b);
    }
    if (at < right) rects.push([at, row, right - at, 1]);
  }
  return rects;
}

return { TRANSITIONS, transitionMs, transitionFrame };
})();

__m['reel.js'] = (() => {
// Checks a reel (the object a reel.js file exports) and fills in its defaults.
// Pure: no DOM, so the same checks run in the browser, in the tools and in the tests.
const { drawPicture, pictureProblems } = __m['pictures.js'];
const { TRANSITIONS } = __m['transitions.js'];

/** A reel name doubles as its folder name under reels/, so keep it URL- and file-safe. */
const REEL_NAME = /^[a-z0-9][a-z0-9-]{0,63}$/;

class ReelError extends Error {
  constructor(problems) {
    super('This reel has problems:\n- ' + problems.join('\n- '));
    this.name = 'ReelError';
    this.problems = problems;
  }
}

/** How captions appear: all at once, or typed out as the narrator speaks. */
const CAPTION_STYLES = ['plain', 'typewriter'];

const isText = (v) => typeof v === 'string' && v.trim() !== '';
const oneOf = (list) => list.map((v) => `'${v}'`).join(', ');

/**
 * Returns a clean copy of `raw`:
 *   { title, intro, note, transition, captions, images: { name: url },
 *     scenes: [{ title, caption, say, draw, transition, captions }] }
 * `base` is put in front of relative image paths (the reel's folder, for example
 * "reels/my-reel/"). Throws a ReelError listing every problem found, not just the first.
 */
function normalizeReel(raw, { base = '' } = {}) {
  const problems = [];
  if (!raw || typeof raw !== 'object') throw new ReelError(['the reel file must export an object (export default { ... })']);

  if (!isText(raw.title)) problems.push('title: give the reel a title');
  for (const key of ['intro', 'note']) {
    if (raw[key] !== undefined && typeof raw[key] !== 'string') problems.push(`${key}: must be text`);
  }
  const transition = raw.transition ?? 'cut', captions = raw.captions ?? 'plain';
  if (!TRANSITIONS.includes(transition)) problems.push(`transition: must be one of ${oneOf(TRANSITIONS)}`);
  if (!CAPTION_STYLES.includes(captions)) problems.push(`captions: must be one of ${oneOf(CAPTION_STYLES)}`);

  const images = {};
  if (raw.images !== undefined) {
    if (!raw.images || typeof raw.images !== 'object' || Array.isArray(raw.images)) {
      problems.push('images: must be an object of { name: "path/to/picture.png" }');
    } else {
      for (const [name, src] of Object.entries(raw.images)) {
        if (!isText(src)) { problems.push(`images.${name}: must be a path to a picture`); continue; }
        images[name] = /^([a-z][a-z0-9+.-]*:|\/)/i.test(src) ? src : base + src;
      }
    }
  }

  const scenes = [];
  if (!Array.isArray(raw.scenes) || raw.scenes.length === 0) {
    problems.push('scenes: give the reel at least one scene');
  } else {
    raw.scenes.forEach((s, i) => {
      const where = `scene ${i + 1}`;
      if (!s || typeof s !== 'object') { problems.push(`${where}: must be an object`); return; }
      if (!isText(s.title)) problems.push(`${where}: needs a title`);
      if (!isText(s.caption)) problems.push(`${where}: needs a caption`);
      if (s.say !== undefined && !isText(s.say)) problems.push(`${where}: say must be text (or leave it out to read the caption)`);
      if (s.draw !== undefined && typeof s.draw !== 'function') problems.push(`${where}: draw must be a function draw(t, px)`);
      if (s.transition !== undefined && !TRANSITIONS.includes(s.transition)) problems.push(`${where}: transition must be one of ${oneOf(TRANSITIONS)}`);
      if (s.captions !== undefined && !CAPTION_STYLES.includes(s.captions)) problems.push(`${where}: captions must be one of ${oneOf(CAPTION_STYLES)}`);
      let draw = typeof s.draw === 'function' ? s.draw : defaultDraw;
      if (s.picture !== undefined) {
        const wrong = s.draw !== undefined ? ['give it draw or picture, not both'] : pictureProblems(s.picture, Object.keys(images));
        for (const p of wrong) problems.push(`${where}: ${p}`);
        if (!wrong.length) draw = (t, px) => drawPicture(s.picture, t, px);
      }
      scenes.push({
        title: s.title,
        caption: s.caption,
        say: isText(s.say) ? s.say.trim() : String(s.caption ?? '').trim(),
        draw,
        transition: s.transition ?? transition,
        captions: s.captions ?? captions
      });
    });
  }

  if (problems.length) throw new ReelError(problems);
  return {
    title: raw.title.trim(),
    intro: raw.intro ?? 'Sound will start. Use Next and Back any time.',
    note: raw.note ?? '',
    transition,
    captions,
    images,
    scenes
  };
}

/** A plain title card, for scenes that do not draw their own picture. */
function defaultDraw(t, px, scene) {
  px.rect('#13203a', 0, 0, px.W, px.H);
  px.sign(scene ? scene.title.toUpperCase() : '', px.W / 2, px.H / 2 - 10, 16);
}

/**
 * Turns an audio manifest (written by npm run voices) into a lookup from a
 * scene's narration text to its clip. Clips are matched by their words, not their
 * position, so reordering scenes keeps their recordings, and a scene whose words have
 * changed since the last render has no clip (the browser's own voice reads it instead).
 */
function clipLookup(manifest, base = '') {
  const byText = new Map();
  for (const c of manifest?.clips ?? []) {
    if (c && isText(c.text) && isText(c.file)) byText.set(c.text.trim(), { url: base + c.file, seconds: Number(c.seconds) || 0 });
  }
  return (scene) => byText.get(scene.say) ?? null;
}

return { REEL_NAME, ReelError, CAPTION_STYLES, normalizeReel, defaultDraw, clipLookup };
})();

__m['format.js'] = (() => {
// A reel as plain data: the reel.json format. It is the reel.js format without the code, so
// a reel can be written by a tool, an AI agent or a web service and played safely, since
// nothing in it ever runs. Every picture comes from the ready-made ones (pictures.js).
// Pure: no DOM, so the same checks run in the browser, in the tools and in the tests.
const { PICTURES } = __m['pictures.js'];
const { CAPTION_STYLES, normalizeReel, ReelError } = __m['reel.js'];
const { TRANSITIONS } = __m['transitions.js'];

/** The format a reel.json names in its "format" field. A new number means a change old readers cannot play. */
const REEL_FORMAT = 'pixelreel/1';

const REEL_KEYS = ['format', 'title', 'intro', 'note', 'transition', 'captions', 'images', 'scenes'];
const SCENE_KEYS = ['title', 'caption', 'say', 'picture', 'transition', 'captions'];

/** What each ready-made picture shows, for people and agents choosing one. */
const PICTURE_NOTES = {
  title: 'A big title dropping in over a night sky, with a line typed underneath.',
  list: 'Items arriving one by one with a tick, or a number, every few seconds.',
  terminal: 'A terminal window. Lines starting with "$ " type out; the rest is output.',
  code: 'An editor that types out the code, with simple highlighting.',
  chat: 'Messages arriving with a typing indicator. The first sender sits on the left.',
  big: 'One huge word or number, punched in, with a line underneath.',
  image: "One of the reel's own images, named in images, slowly pushing in."
};

const isPlainObject = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);

/** Every place in `value` that holds code (a function), as paths such as "scenes[2].draw". */
function codePaths(value, path = '', found = []) {
  if (typeof value === 'function') found.push(path);
  else if (Array.isArray(value)) value.forEach((v, i) => codePaths(v, `${path}[${i}]`, found));
  else if (isPlainObject(value)) for (const [key, v] of Object.entries(value)) codePaths(v, path ? `${path}.${key}` : key, found);
  return found;
}

/**
 * Everything that makes `raw` not a reel.json in its own right, beyond the checks every reel
 * gets: the format it names, fields it does not know, and code. Empty when it is fine.
 */
function dataProblems(raw) {
  const problems = [];
  if (raw.format === undefined) problems.push(`format: say which format this is, "format": "${REEL_FORMAT}"`);
  else if (raw.format !== REEL_FORMAT) problems.push(`format: this player reads "${REEL_FORMAT}", not ${JSON.stringify(raw.format)}`);
  for (const key of Object.keys(raw)) {
    if (!REEL_KEYS.includes(key)) problems.push(`${key}: a reel has ${REEL_KEYS.join(', ')}, not ${key}`);
  }
  if (Array.isArray(raw.scenes)) {
    raw.scenes.forEach((s, i) => {
      if (!isPlainObject(s)) return;
      for (const key of Object.keys(s)) {
        if (key === 'draw') problems.push(`scene ${i + 1}: draw is code, which a reel.json cannot hold; give the scene a picture instead`);
        else if (!SCENE_KEYS.includes(key)) problems.push(`scene ${i + 1}: a scene has ${SCENE_KEYS.join(', ')}, not ${key}`);
      }
    });
  }
  for (const path of codePaths(raw)) {
    if (!/^scenes\[\d+\]\.draw$/.test(path)) problems.push(`${path}: a reel.json holds data only, not code`);
  }
  return problems;
}

/**
 * Checks a reel.json (already parsed) and returns it ready to play, exactly as normalizeReel
 * does for a reel.js. Throws a ReelError listing every problem found, not just the first.
 */
function reelFromData(raw, { base = '' } = {}) {
  if (!isPlainObject(raw)) {
    throw new ReelError([`a reel.json must be one object, such as { "format": "${REEL_FORMAT}", "title": "Tea", "scenes": [ ... ] }`]);
  }
  const problems = dataProblems(raw);
  // Only the fields a reel.json may have go on to the usual checks, so nothing is said twice.
  const scenes = Array.isArray(raw.scenes)
    ? raw.scenes.map((s) => (isPlainObject(s) ? Object.fromEntries(SCENE_KEYS.filter((k) => k in s).map((k) => [k, s[k]])) : s))
    : raw.scenes;
  try {
    const reel = normalizeReel({ ...raw, scenes }, { base });
    if (!problems.length) return reel;
  } catch (err) {
    if (!(err instanceof ReelError)) throw err;
    problems.push(...err.problems);
  }
  throw new ReelError(problems);
}

/** Reads the text of a reel.json and checks it. Throws a ReelError if it is not JSON or not a reel. */
function parseReelJson(text, options) {
  let raw;
  try {
    raw = JSON.parse(text);
  } catch (err) {
    throw new ReelError([`this is not valid JSON: ${err.message}`]);
  }
  return reelFromData(raw, options);
}

const TEXT = { type: 'string', pattern: '\\S' };
const KIND_SCHEMAS = {
  text: TEXT,
  list: { type: 'array', minItems: 1, items: { type: 'string' } },
  messages: {
    type: 'array',
    minItems: 1,
    items: { type: 'object', additionalProperties: false, required: ['from', 'text'], properties: { from: TEXT, text: TEXT } }
  },
  number: { type: 'number', minimum: 0, description: 'Seconds.' },
  flag: { type: 'boolean' },
  image: { type: 'string', description: "The name of one of the reel's images." }
};

/**
 * The reel.json format as a JSON Schema (draft 2020-12), built from the ready-made pictures,
 * so it can never drift from what the player draws. Tools can hand it to an AI agent as the
 * shape to write. A few rules are beyond a schema (an image picture must name one of the
 * reel's images), so reelFromData stays the final word.
 */
function reelSchema() {
  const pictures = Object.entries(PICTURES).map(([type, { fields }]) => {
    const properties = { type: { const: type } }, required = ['type'];
    for (const [key, want] of Object.entries(fields)) {
      properties[key] = KIND_SCHEMAS[want.replace('?', '')];
      if (!want.endsWith('?')) required.push(key);
    }
    return { title: type, description: PICTURE_NOTES[type], type: 'object', additionalProperties: false, required, properties };
  });
  return {
    $schema: 'https://json-schema.org/draft/2020-12/schema',
    title: 'pixelreel reel',
    description: 'A narrated pixel-art explainer: a list of scenes, each with a title, a caption, words to say and a ready-made picture.',
    type: 'object',
    additionalProperties: false,
    required: ['format', 'title', 'scenes'],
    properties: {
      format: { const: REEL_FORMAT },
      title: { ...TEXT, description: "The reel's name, shown above the player." },
      intro: { type: 'string', description: 'Shown before anyone presses Play.' },
      note: { type: 'string', description: 'Small print under the player.' },
      transition: { enum: TRANSITIONS, default: 'cut', description: 'How every scene enters, unless it says otherwise.' },
      captions: { enum: CAPTION_STYLES, default: 'plain', description: 'Captions all at once, or typed out as the narrator speaks.' },
      images: {
        type: 'object',
        description: 'Pictures the scenes can show, as name: path or URL.',
        additionalProperties: { type: 'string', minLength: 1 }
      },
      scenes: { type: 'array', minItems: 1, items: { $ref: '#/$defs/scene' } }
    },
    $defs: {
      scene: {
        type: 'object',
        additionalProperties: false,
        required: ['title', 'caption'],
        properties: {
          title: { ...TEXT, description: 'The heading over the caption.' },
          caption: { ...TEXT, description: 'The words on screen. Short sentences read best.' },
          say: { ...TEXT, description: 'What the narrator says. Leave it out to read the caption aloud.' },
          picture: { $ref: '#/$defs/picture' },
          transition: { enum: TRANSITIONS, description: "How this scene enters, overriding the reel's." },
          captions: { enum: CAPTION_STYLES, description: "Overrides the reel's caption style." }
        }
      },
      picture: { description: 'A ready-made picture. Leave it out for a plain title card.', oneOf: pictures }
    }
  };
}

return { REEL_FORMAT, PICTURE_NOTES, reelFromData, parseReelJson, reelSchema };
})();

__m['timing.js'] = (() => {
// How long things take. Pure functions, shared by the player and the tests.

/** Pause after a scene's narration ends, before the next scene starts. */
const GAP_MS = 1200;

/** Speaking rate used to guess how long a line takes when no recording exists. */
const WORDS_PER_SECOND = 2.5;

/** No scene is shorter than this, even one with very few words. */
const MIN_SCENE_MS = 4000;

/** Counts the words in a line of narration. */
function countWords(text) {
  const trimmed = String(text ?? '').trim();
  return trimmed ? trimmed.split(/\s+/).length : 0;
}

/** A guess at how long `text` takes to say aloud, in milliseconds. */
function estimateSpeechMs(text) {
  return Math.max(MIN_SCENE_MS, Math.round((countWords(text) / WORDS_PER_SECOND) * 1000));
}

/**
 * How long a scene's narration lasts: the recorded clip's length when there is one,
 * otherwise a guess from the number of words. Never shorter than MIN_SCENE_MS.
 */
function narrationMs(scene, clip) {
  if (clip && Number.isFinite(clip.seconds) && clip.seconds > 0) {
    return Math.max(MIN_SCENE_MS, Math.round(clip.seconds * 1000));
  }
  return estimateSpeechMs(scene.say);
}

/**
 * The longest we wait for the browser's own voice to say it has finished. Some browsers
 * never fire the end event, so the player moves on after this rather than stalling.
 */
function speechWatchdogMs(text) {
  return estimateSpeechMs(text) * 2 + 5000;
}

/**
 * Lays the scenes end to end: where each one starts on the reel's clock and how long it
 * lasts, its narration plus the pause after it. `durations` are narration lengths in ms.
 * Returns { starts, spans, total }, all in milliseconds.
 */
function timeline(durations, gapMs = GAP_MS) {
  const starts = [], spans = [];
  let at = 0;
  for (const d of durations) {
    starts.push(at);
    const span = Math.max(0, Number(d) || 0) + gapMs;
    spans.push(span);
    at += span;
  }
  return { starts, spans, total: at };
}

/** Which scene is playing `ms` into the reel, and how far into it: { index, offset }. */
function locate(line, ms) {
  const { starts, total } = line;
  if (!starts.length) return { index: 0, offset: 0 };
  const at = Math.max(0, Math.min(total, Number(ms) || 0));
  let index = starts.length - 1;
  while (index > 0 && starts[index] > at) index--;
  return { index, offset: at - starts[index] };
}

/** A time for people: 83000 becomes "1:23". */
function clockTime(ms) {
  const s = Math.max(0, Math.floor((Number(ms) || 0) / 1000));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}

/** Typewriter captions finish typing at this share of the narration, so the words lead the voice. */
const TYPE_SHARE = 0.7;

/** ...but never type slower than this many characters a second. */
const TYPE_MIN_CPS = 12;

/** How many characters of `text` a typewriter caption shows `elapsedMs` into narration lasting `narrationMs`. */
function typedLength(text, elapsedMs, narrationMs) {
  const len = String(text ?? '').length;
  if (!len) return 0;
  const typingMs = Math.min(narrationMs * TYPE_SHARE, (len / TYPE_MIN_CPS) * 1000);
  if (!(typingMs > 0)) return len;
  return Math.max(0, Math.min(len, Math.ceil((len * elapsedMs) / typingMs)));
}

return { GAP_MS, WORDS_PER_SECOND, MIN_SCENE_MS, countWords, estimateSpeechMs, narrationMs, speechWatchdogMs, timeline, locate, clockTime, TYPE_SHARE, TYPE_MIN_CPS, typedLength };
})();

const { parseReelJson } = __m['format.js'];
const { clockTime, narrationMs, timeline } = __m['timing.js'];
const [input, output] = process.argv.slice(2);
if (!input) {
  console.error('Usage: node make-page.mjs reel.json [page.html]');
  process.exit(2);
}
const text = readFileSync(input, 'utf8');
let reel;
try {
  reel = parseReelJson(text);
} catch (err) {
  if (!err.problems) throw err;
  console.error('This reel has problems. Fix them all, then run this again:\n- ' + err.problems.join('\n- '));
  process.exit(1);
}
const escapeHtml = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const reelJson = JSON.stringify(JSON.parse(text)).replace(/</g, '\\u003c');
const template = readFileSync(join(dirname(fileURLToPath(import.meta.url)), 'template.html'), 'utf8');
const page = template
  .replace(/<title>[^<]*<\/title>/, () => '<title>' + escapeHtml(reel.title) + ' - pixelreel</title>')
  .replace('PIXELREEL_REEL_HERE', () => reelJson);
const out = output || basename(input).replace(/\.json$/i, '') + '.html';
writeFileSync(out, page);
const length = timeline(reel.scenes.map((s) => narrationMs(s, null))).total;
console.log('Wrote ' + out + ': "' + reel.title + '", ' + reel.scenes.length + ' scenes, about ' + clockTime(length) + '.');

