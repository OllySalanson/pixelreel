# Message in a Bottle

A small button for leaving notes on a website's pages, seen only by the people on that site's
list. One service runs it for every site it is on: an agency's own site with each client's preview
under it, and live sites of their own.
Someone on a site's list presses Suggest a change, clicks the part of the page the note is about (or chooses
the whole page), types or says the note (see "Saying a note aloud"), and sends it. Each note
arrives with:

- a screenshot of what was on the screen, with the chosen part outlined in red,
- the page's address and title,
- a CSS selector for that part, its tag and its words,
- the window's size, scale and how far it was scrolled, and the browser,
- the `data-` settings on the page's `<html>` (a site's own display choices, say),
- who left it, and whether it was said aloud.

Whoever looks after the sites works through each site's queue, marks every note with what came
of it, and the person who left it is emailed what came of it (all their notes since the last
email in one, at most an hour apart). The page shows nothing but the Suggest a change button.
What a client sees calls a note a suggestion; whoever looks after the sites calls them notes.

Nobody else sees any of it. Every page loads `bottle.js`, but without a key or a link it does
nothing: no button, no request (except on a preview, below, where the button is for anyone). Search engines are kept out of everything it answers. The screenshot is made
in the browser by [modern-screenshot](https://github.com/qq15725/modern-screenshot) (MIT),
served by the service itself, so no other company is involved.

It knows nothing of any one website: everything about a site is in its settings and its list.
The endpoint is plain Node (20.6 or later) with no packages but modern-screenshot.
`npm install && npm run check` here runs its lint and tests.

## Saying a note aloud

Speak writes the words into the box as they are heard, where they can be put right before
sending.

- **Where the browser hears** (Chrome, Edge, Safari on a Mac, an iPhone or an iPad), its own
  speech recognition does it.
- **Where it cannot** (Brave has the name but no service behind it, Firefox has none, and any
  browser whose recognition fails with a `network` error), the button records the microphone
  and sends it, a few seconds at a time, to a speech service, if the endpoint was given one
  (`hear`, or `BOTTLE_HEAR` on its own). The words so far come back every second or so, and
  are put right as more is heard; pressing Stop says "One moment" while the last of them are
  written down. Silence is never sent. The service takes `POST` mono 16-bit little-endian
  samples at 16,000 a second, at most 12 seconds, and answers `{ "text": ... }`; it must take
  requests from every site's pages. Pixel Reel's `/hear` (a small Whisper model on its own
  machine) is one.
- **Where neither can**, there is no Speak. A browser whose recognition turns out to be
  missing, with no speech service to fall back on, says "This browser cannot hear you. Type it
  instead." once and never shows Speak again. A refused microphone says so, and Speak stays.

Where there is no Speak, a phone's own keyboard microphone still types a note into the box. A
site whose content security policy limits `connect-src` must allow the speech service's
address too.

## In Claude

Someone on a site's list can also send suggestions by talking to Claude. They add the site
as a connector in Claude once; then "Tell Olly I'm happy to be messaged on WhatsApp", or "the
phone number on the Parties page is the old one", goes into the site's queue like any other
suggestion, under their name and marked as from Claude. It is dealt with in the same way (done,
held or declined), and they hear what came of it the same way.

- **The address** is theirs alone: `<service>/bottle/mcp/<key>`, with a key made for it
  (`bottles person claude <site> <person>`). It works until they are turned off, like every key
  of theirs. Nothing else is needed: no account, no API key.
- **Adding it themselves:** once their button is on, the site's `/review` page has **Add to
  Claude**. It makes them an address of their own and opens Claude's own "add a custom
  connector" box with it filled in (named "<Site>: Suggest a change"), so they press Add there.
  Five an hour, from their own site's pages.
- **Adding it for them:** the same command prints an Add to Claude link to send them. Opened in
  a browser signed in to Claude, it needs only Add.
- **One tool**, `suggest_change`: what should change (or the message), in their words, and the
  page if they named one (its address, its path, or its name, such as "Parties"). It changes
  nothing on the site, and reads nothing back.
- **The same limits** as the button. A suggestion from Claude has no screenshot, and is about
  the whole page.
- **How it answers**: the Model Context Protocol over HTTP (Streamable HTTP, plain JSON
  answers, no session), written in `mcp.mjs` with no packages. Only Claude's servers ask it: a
  request from a page in a browser is turned away. The key is in the address, so it is in any
  log of addresses the host keeps.

## Two ways to run it

**On its own** (`main.mjs`, started by `start.cjs`), keeping everything in a folder. This is
for a host that runs Node and nothing else of ours, such as an agency's own site on shared
hosting, where each client's preview lives in a folder of its own (`https://agency.example/harbour/`)
and every one of them sends its notes to `https://agency.example/bottle`. See "Running it on its
own", below.

**Mounted in a Node server of your own** (`createBottle` in `server.mjs`), keeping everything in
that server's own store. This is for a live site that already runs a Node service, which then
answers `<site>/bottle` itself, as Pixel Reel's does (`https://pixelreel.pro/bottle`). See "The
endpoint", below.

Either way the page of queues is at `<service>/bottle` (also `<service>/bottle/admin`).

## How a client gets the button

1. Whoever looks after the sites puts them on the site's list (`bottles person add`) and sends
   them the invitation (`bottles invite`), "<Site>: your link to suggest changes to the new
   site". It holds a link such as `https://theirsite.com/#bottle=<code>`, which works for 7 days on any
   phone or computer it is opened on. The code is after `#`, which a browser never sends to the
   site, so it is in none of the site's logs, and the page takes it out of its address at once.
2. Opening it shows one small card, "Switch on Suggest a change". Pressing it swaps the code for a
   key of that browser's own, which it keeps, so the button is there on every page of that site
   from then on, and says "The Suggest a change button is on". Only the press uses the link, so
   a mail scanner that opens it uses nothing up. A new invitation (`invite` or `person link`) retires the last.
3. On another phone or computer, or once the link has run out, they go to the site's short
   address, `theirsite.com/review` ("Review <Site>") and give their email. If it is on the site's
   list, the service emails them a sign-in link the same way (it works once, for 30 minutes; at
   most five a day). Anyone else is told the same ("If that address is on the list, a link is on
   its way"), with Send again, and sent nothing, so the page says nothing about who is on the list.
4. `/review` says the button is on, and Turn off there forgets the key.

A link that has run out (used, too old, retired, or its person turned off) says "This link has run
out", with Get a new link to `/review`; opened in a browser whose key still works, it leaves the
button on and says so. A kept key that stops working shows nothing, and the browser forgets it:
that browser could be anyone's. `#bottle=off` on any page forgets the key as well. Links sent
before links held codes (`?bottle=<key>`) still work.

## A live site's word: `/suggest`

A live site may instead have a word, one simple word that whoever looks after the site tells its
people (on a call, say), which is easy to remember on the sofa in the evening: no link, no email.

1. Give the site its word: `bottles site word elevation-project <word>` (in any case; `off`
   takes it away). Only a hash of it is kept, and nothing ever says what it is.
2. The site has a page at `/suggest` with the line with `data-suggest` in it, and nothing for a
   search engine (as `/review`, below, with `data-suggest` for `data-review`).
3. Someone goes to `theirsite.com/suggest` ("Suggest a change to <Site>"), and gives the word and
   their name, once. Their browser is given a key of its own, which works for a year, so the
   Suggest a change button is on, on every page of that site, and it never asks again there.
4. Someone who joined that way is **waiting**: their suggestions go nowhere near the queue, and
   wait under Waiting on the page of queues until whoever looks after the site approves them
   there (Approve <name>) or with `bottles person approve <site> <person>`. Approving them, once,
   puts what they left in the queue, and everything they leave from then on goes straight there.
   Turn off ends their key instead.

Nobody else sees anything: every other page loads `bottle.js` and, with no key, does nothing.
A wrong word counts as a wrong key, so a caller who gives ten in an hour is turned away for the
hour, whatever they give, the right word included; and once a site has been given 100 wrong words
in a day, from anyone, it takes none until the day is out. Joining takes five names an hour from a
caller, and fifty people a day on a site, as a preview does.

The word is the one way in yet. Another, such as a code sent to someone's phone, would be one
more way to join (`POST /bottle/join` with its own `by`, a method beside `joinByWord` in
`sites.mjs`, and a step in `suggest()` in `bottle-ui.mjs`), ending the same way.

## A preview: the button for anyone

A site can be marked as a preview (`bottles site add <id> --preview`; `--live` makes it a live
site again). Its pages' line says so too, with `data-preview`:

```html
<script src="https://agency.example/bottle/bottle.js" data-preview defer></script>
```

Then anyone who opens one of its pages sees Suggest a change. The first press asks their name ("Your name",
Next), which puts them on the site's list by that name, with no email, and gives their browser a
key of its own, kept like any other; from then on it is the button as everyone else has it, My
notes and all, and it never asks again in that browser. Nobody is emailed anything about a
preview's notes, since nobody gave an address. A caller may give five names an hour, and a
preview takes fifty people a day. Links and keys work there as on any site, so someone sent a
link before keeps it.

Both are needed: `data-preview` alone on a live site's pages does nothing (the service says the
site is not a preview), and a site marked as a preview shows nothing to strangers on pages whose
line lacks it, so a page with the line asks the service only where it was meant to.

## Putting it on a site

1. Add the site: `bottles site add civ-speak --name "Civ Speak" --origin https://civspeak.com`
   (more than one `--origin` if it is at more than one address). A site that lives under a path,
   such as a preview at `https://example.com/preview/`, is added with that whole address: its
   pages are known by their origin, as any site's, and its links open that page, not the
   origin's home page. Where more than one site lives at one address (each client's preview in a
   folder of an agency's site), every page's line names its site, `data-site="<id>"`: the
   browser keeps a key for each site apart, and a key or link of one site does not work on
   another's pages. A page whose line names no site is on the site at the whole address.
2. Put the one line on every page, the service's address in it (here `https://agency.example`):

   ```html
   <script src="https://agency.example/bottle/bottle.js" defer></script>
   ```

3. Give the site a page at `/review` for signing in: the line with `data-review` in it, and
   nothing for a search engine:

   ```html
   <!doctype html>
   <html lang="en">
   <head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
   <meta name="robots" content="noindex, nofollow"><title>Review</title></head>
   <body><script src="https://agency.example/bottle/bottle.js" data-review defer></script></body>
   </html>
   ```

   `data-review` makes the page the sign-in box, whatever its address, and only a page with it
   is one, so a site's own page of customer reviews is left alone.
4. If the site has a content security policy, it must let the service's scripts load and be asked
   (`script-src` and `connect-src` with the service's address), and allow `data:` pictures
   (`img-src data:`), which is how the screenshot is drawn.
5. To have the Suggest a change button in the site's own design (in its top bar, say), give the page a button
   of its own with `data-bottle-note`, hidden to begin with:

   ```html
   <button type="button" data-bottle-note hidden>Suggest a change</button>
   ```

   Then Bottle draws no button of its own: it shows the page's (removing `hidden`) once the button
   would be on for this browser (a key, a link, or a preview), and a press of it starts a note as
   its own would (on a preview, the first press asks the name). Without a key, it stays hidden.

A service mounted in a site's own server can serve that site's `/review` page itself (`review:
'/review'`, or `BOTTLE_REVIEW=/review` on its own), so the site needs no page of its own for it.

## Running it on its own

```sh
npm install --omit=dev
BOTTLE_ORIGINS=https://agency.example BOTTLE_KEY=<owner key> BOTTLE_READER=<admin key> \
  BOTTLE_DATA=/home/agency/bottle-data npm start
```

It answers everything under `/bottle` (and `/health`, and `/bottle/health`), so the host sends
it every address under `https://agency.example/bottle`, with the whole path, and serves the
site's pages itself. Two long random keys will do (`node -e "console.log(require('crypto').randomBytes(24).toString('base64url'))"`).
Its settings:

| Setting | What it is |
| --- | --- |
| `PORT` (or `BOTTLE_PORT`) | Where it listens; 8790 if neither is set. A host that starts it may set this itself. |
| `BOTTLE_DATA` | The folder everything is kept in (`data` beside it if not set). Keep it out of the site's public folder, and back it up. |
| `BOTTLE_ORIGINS` | The home site's addresses, separated by commas, such as `https://agency.example`. |
| `BOTTLE_HOME_ID`, `BOTTLE_HOME_NAME` | The home site's id and name (`home`, "This site"). |
| `BOTTLE_KEY` | The owner's own key: `https://agency.example/#bottle=<key>` turns the button on for the owner. |
| `BOTTLE_OWNER_ID`, `BOTTLE_OWNER_NAME` | Who the owner is (`owner`, "Owner"). |
| `BOTTLE_READER` | The admin key, which `bottles` and the page of queues ask for. |
| `BOTTLE_REVIEW` | The home site's sign-in page for it to serve, such as `/review`; none if not set. |
| `BOTTLE_HEAR` | A speech service's address, for Speak where the browser cannot hear (see "Saying a note aloud"); none if not set. |
| `BOTTLE_TRUST_PROXY` | How many proxies stand in front of it, so it knows who is asking (0). |
| `BOTTLE_RESEND_KEY`, `BOTTLE_MAIL_FROM` | Both set, it sends email through Resend from that address; otherwise every email is kept in the outbox. |
| `BOTTLE_FROM`, `BOTTLE_REPLY_TO`, `BOTTLE_NOTIFY` | Who signs the emails, where a reply goes, and who is told of new notes (the reply address if not set). |
| `BOTTLE_RESEND_WEBHOOK_SECRET` | The signing secret of the Resend webhook that says when an email bounced. |

On cPanel hosting with a Node.js selector ("Setup Node.js App"): put these files in a folder
outside `public_html`, make an app with Node 20 or later whose application root is that folder,
whose application URL is the site's `/bottle` and whose startup file is `start.cjs`, add the
settings as its environment variables, and press Run NPM Install. Such hosts put an app to sleep
when nobody uses it, so news of notes waits for the next visit: a cron job that opens
`https://agency.example/bottle/health` every few minutes keeps it awake.

Each client preview in a folder of its own is a site of its own, added with its whole address
(`bottles site add harbour --name "Harbour Bakery" --origin https://agency.example/harbour/
--preview`), and its pages carry the line with `data-preview` and `data-site="harbour"`:

```html
<script src="https://agency.example/bottle/bottle.js" data-preview data-site="harbour" defer></script>
```

## Looking after the sites

`bottles` (`bottles.mjs`; `npx bottles` here, or wherever the package is installed) is the
admin tool. Give it the service's address with `--service <address>` (or `BOTTLE_SERVICE`) and
the admin key in `BOTTLE_READER`, or have gcloud read the key from Google Secret Manager with
`--gcloud-secret <name> --project <project>` (which needs a gcloud signed in to that project).
A site that uses it often can name all of that once in an npm script of its own.

### Sites and people

```sh
bottles sites                                            # every site, with its queue
bottles site add civ-speak --name "Civ Speak" --origin https://civspeak.com
bottles person add civ-speak --name "Ann Lee" --email ann@example.com   # prints her link (7 days)
bottles invite civ-speak ann-lee                         # emails her a new invitation
bottles invite civ-speak ann-lee --to you@example.com    # a preview of it, with no link in it
bottles people civ-speak                                 # with the last email to each, and their link's end
bottles person off civ-speak ann-lee                     # every key and link of hers stops working, for good
bottles person on civ-speak ann-lee                      # then send her a new invitation
bottles person link civ-speak ann-lee                    # a new link for her (the last one stops working)
bottles person claude civ-speak ann-lee                  # an address of hers for Claude (see "In Claude")
bottles site word civ-speak dizzy                        # its word, for its /suggest page (off takes it away)
bottles person approve civ-speak sarah                   # someone who joined with the word: their suggestions join the queue
bottles person email civ-speak ann-lee ann.lee@example.com   # corrects her address
bottles outbox                                           # the emails kept instead of sent
```

A person's id is made from their name (`ann-lee`). Only a hash of each key and code is kept, so
the store holds no key that works; a link is printed once, when it is made. Turning someone off
ends every key and link they have, so turning them on again brings back none of them, not even
one they passed on. Correcting an address does the same, so a link sent to a wrong one is dead.
`people` shows what became of the last email to each person (an invitation sent, or in the
outbox; bounced or marked as spam, once Resend's webhook says so) and until when their
invitation's link works.

### Working through a queue

Every note is triaged into one of three outcomes, and goes through these states:

| State | What it means |
| --- | --- |
| `new` | Just left. |
| `in-progress` | Someone is on it. |
| `held` | Doing it would harm the site's SEO or brand. Not done: the conflict and a proposed solution wait for the owner's decision. Held is the owner's only inbox. |
| `declined` | It would be bad for the client in a way they may not see. Not done, and the reason is one or two plain sentences beginning "We haven't done this because...", the risk in one plain unit they understand (enquiries, calls, sales), never mixing measures. |
| `done` | On the preview, with what was done and how sure (0 to 100) it is what was meant. Its writer is emailed, once (see "Sending email"). |
| `closed` | Its writer said it is right (`bottles close <id>`, when they say so). |

```sh
bottles queue harbour                 # its open notes: new, in progress, held
bottles fetch --site harbour --state open   # each into .bottles/<id>/: note.json and shot.jpg
bottles show <id>
bottles start <id>
bottles done <id> --what "The heading is smaller on a phone." --confidence 90
bottles held <id> --conflict "SEO: ..." --proposal "..."
bottles declined <id> --reason "We haven't removed the Worthing page. It brings in about 4 enquiries a month, and removing it would lose most of them."
bottles results harbour               # the table: request, what was done, confidence, conflict
bottles list --site harbour --state all --json   # everything, for a script
```

Its writer sees only their own notes, and of those only what is theirs to see: a held note is
"waiting" to them (it may yet be declined), and only done and declined notes say what came of
them.

### The page of queues

`/bottle` on the service (`https://agency.example/bottle`, or `/bottle/admin`) lists every site the button
is on, held notes first, with how many of its notes are in each state; each site's notes show
with their screenshots and what came of them. It opens for whoever holds the admin key (it asks
for it), or straight away in a browser that holds the owner's own key (from the owner's link on the home site).
The page holds nothing itself, and is kept out of search engines.

## Sending email

The service builds four emails (`mail.mjs`), each naming the site in its subject: the invitation
(which says who it is from), the sign-in link, the news of what came of a person's notes, and,
to whoever looks after the sites, word of new notes. It sends them with the `mail({ to, subject,
text, replyTo })` function it is given. `resend({ key, from })` in `mail.mjs` is one that sends
through [Resend](https://resend.com); `main.mjs` uses it when `BOTTLE_RESEND_KEY` and
`BOTTLE_MAIL_FROM` are set. Without one, each email is kept in the store's outbox instead
(`bottles/outbox/<id>/mail.json`), `bottles outbox` shows them, and nothing leaves the service.
The sign-in page at `/review` needs real email to be any use to a client, so set a sender up
before giving anyone the short address.

- **Replies.** With `replyTo`, every email ends "Reply to this email to reach <from>" and a
  reply goes there, not to the sending address (which may take no mail).
- **News of notes.** A note marked done or declined joins its writer's next email, which goes
  once nothing has been marked for them for 10 minutes, and no sooner than an hour after the last:
  one email however many notes were marked, listing each under a link to its page. A note is
  marked told only once its email has gone, so one that fails goes next time, and a person turned
  off is sent nothing until they are on again. The service looks every minute; if it was asleep,
  it sends what is due when it next wakes.
- **New notes.** With `notify`, whoever looks after the sites is told when notes come in on a
  site ("Harbour Bakery: 4 new notes", with a link to its queue), the same way: once they stop
  coming for 10 minutes, at most an hour apart. Notes left with the owner's own key are not told.
- **What is kept.** Once emails really go, the outbox kept before is emptied, and each email sent
  is recorded under `bottles/sent/<id>/` with whom it was to, its subject and why, but none of its
  words, so no link. A Resend webhook (`hook`, posting to `/bottle/resend`) says when one bounced
  or was marked as spam, and `bottles people` shows it.

## The parts

| File | What it is |
| --- | --- |
| `bottle.js` | Loaded by every page. A plain script of a few lines that does nothing without a key or a link, except on the `/review` page (`data-review`) and the `/suggest` page (`data-suggest`). It is served asking for the very `bottle-ui.mjs` served with it, so a browser never runs one with the other from before a change. |
| `hear-worklet.js` | Hands the microphone's sound to the button, where a speech service writes the note down. |
| `bottle-ui.mjs` | The button and what it opens, the `/review` sign-in box and the `/suggest` box for a site's word, loaded only when needed. Drawn in a shadow root and styled with `adoptedStyleSheets`, so the page's styles cannot reach it and a strict content security policy (no inline styles or scripts) does not stop it. |
| `server.mjs` | The endpoint: `createBottle(...)` gives `handle(req, res)`, which answers everything under `/bottle` (and the home site's `/review` page) and returns false for anything else. |
| `sites.mjs` | The sites, the people on their lists, their keys and sign-in codes. |
| `mail.mjs` | The emails, the Resend sender, and the outbox that keeps them when nothing sends them. |
| `mcp.mjs` | The connector for Claude (see "In Claude"). |
| `admin.mjs`, `admin.css` | The page of queues. |
| `bottles.mjs` | The admin tool. |
| `main.mjs`, `start.cjs` | The service on its own, from its environment; `start.cjs` starts it. |
| `store.mjs` | `FolderStore`, a store in a folder. |
| `test/` | The tests: the endpoint, the emails and the tool with a store kept in memory, and the service on its own. |

### The endpoint

`createBottle` takes:

- `store`: where everything is kept, with `put(key, bytes)`, `get(key)` (null when missing) and
  `folders(prefix)` (and `remove(prefix)`, to empty the outbox). `FolderStore` in `store.mjs`
  does, and so can a store in a bucket.
  Each note is `bottles/<id>/note.json`, with `bottles/<id>/shot.jpg` beside it; the sites are
  `bottles/sites/<site>/site.json`, and keys and codes are kept by their hash under
  `bottles/keys/` and `bottles/codes/`.
- `home` (`{ id, name }`) and `origins`: the site the service is part of, and its addresses.
- `key`: the service's own secret, a key for `owner` (`{ id, name }`), who is on the home site's
  list without being added and may open the page of queues: whoever runs the service.
- `reader`: the admin key. Without it, only the owner's key opens the page of queues.
- `review`: the home site's own sign-in page, such as `/review`.
- `hear`: a speech service's address, relative to the endpoint's own (such as `/hear`), for Speak
  where the browser cannot hear (see "Saying a note aloud").
- `mail`, `from`, `replyTo`: how to send email, who signs it, and where a reply goes (see above).
- `notify`: the address told when new notes come in; `hook`: the signing secret of a Resend
  webhook (`whsec_...`), which says when an email bounced.
- `quiet` (10 minutes), `gap` (an hour), `every` (a minute): when news of notes is sent (see
  above), and how often it looks. `tell()` sends whatever is due now.
- `caller(req)`: who is asking, for the limits (behind a proxy, the address it passed on).
- `perHour` (30), `perDay` (200): notes each person may leave in an hour, and each site in a
  day; `wrongPerHour` (10): wrong keys a caller may try in an hour before being turned away;
  `signInsPerHour` (5): sign-in links a caller may ask for in an hour (and three for each address,
  and five a day for each person on a list, counted in the store); `visitsPerHour` (5),
  `visitsPerDay` (50): names a caller may give in an hour, on a preview or with a site's word, and
  people a site takes that way in a day; `wrongWordsPerDay` (100): wrong words a site may be given
  in a day, from anyone, before it takes none.

A screenshot bigger than 4 MB is not kept (the note still is), and no note may be bigger than 6 MB.

| Request | Key | Answer |
| --- | --- | --- |
| `GET /bottle/bottle.js`, `bottle-ui.mjs`, `shot.mjs`, `admin.mjs`, `admin.css` | none | The files, to any site. |
| `GET /review`, `/bottle/admin` | none | The sign-in page and the page of queues, with nothing on them until a script draws it. |
| `POST /bottle/check` | `x-bottle-key` | 200 if the key is right, from that person's site. A link's code that still works answers 409 `{ code: true }`; with `{ "use": true }` it answers `{ key }`, a key of the person's own (a sign-in code once, an invitation's for 7 days). |
| `POST /bottle/site` | none | `{ name }` of the site the page asking is on, for its `/review` and `/suggest` pages, with `preview: true` for a preview and `word: true` for a site with a word. |
| `POST /bottle/visit` | none | `{ "name": ... }` from a preview's page: 201 `{ key, name }`, a key of their own. 403 from any other site. |
| `POST /bottle/join` | none | `{ "by": "word", "word": ..., "name": ... }` from a page of a site with a word: 201 `{ key, name }`, a key of their own for a year, waiting to be approved. 403 for a wrong word (counted as a wrong key), 429 once turned away. |
| `POST /bottle/signin` | none | `{ "email": ... }` from one of a site's pages: 202 whatever happens; someone on the list is emailed a link. |
| `POST /bottle/notes` | `x-bottle-key` | 201 `{ id }`. The body is JSON, up to 6 MB with the screenshot (a JPEG data URL in `shot`). |
| `GET /bottle/notes?state=new&site=<id>` | admin | `{ notes }`, oldest first. `state` is one of the states, `open` (new, in progress and held), `waiting` (from people not approved yet, who are in no other list) or `all`. |
| `GET /bottle/notes/<id>`, `.../shot.jpg` | admin | One note, or its screenshot. |
| `PATCH /bottle/notes/<id>` | admin | `{ "state": "done", "what": ..., "confidence": 90 }` (held: `conflict`, `proposal`; declined: `reason`). What came of it is kept in the note's `outcome` and `history`. |
| `GET /bottle/sites`, `POST /bottle/sites` | admin | Every site with its people and its counts by state (and `waiting`); or adds one, `{ id, name, origins, preview, word }` (an address with a path is kept as its `page`, where its links open; `preview` true or false changes what it is; `word` gives it a word, and false takes it away). |
| `GET /bottle/sites/<site>` | admin | One site and its people. |
| `POST /bottle/sites/<site>/people` | admin | `{ name, email }`: adds a person, and answers `{ person, link }`. |
| `PATCH /bottle/sites/<site>/people/<person>` | admin | `{ "on": false }` turns them off, ending every key and link they have; `{ "email": ... }` corrects their address; `{ "approved": true }` approves someone who joined with the word. |
| `POST .../people/<person>/link`, `.../invite` | admin | A new invitation link (retiring the last); or the invitation emailed to them. With `{ "to" }`, a preview of it to that address, with no link in it. |
| `POST /bottle/mcp/<key>` | the key in the address | The connector for Claude: MCP's `initialize`, `ping`, `tools/list` and `tools/call` (`suggest_change`). 404 without a key that works, 403 from a browser. |
| `POST /bottle/claude` | `x-bottle-key` | `{ add }`: the Add to Claude link, with a new address of theirs in it, for the `/review` page's button. |
| `POST .../people/<person>/claude` | admin | `{ address, add }`: a new address of theirs for Claude, and the Add to Claude link with it filled in. |
| `GET /bottle/outbox` | admin | The latest 50 emails kept instead of sent. |
| `POST /bottle/resend` | Resend's signature | A Resend webhook: a bounce or complaint is kept on the person the email was for. |

A page whose line names its site sends `x-bottle-site: <id>` with every request: then only that
site answers, if it is at the page's address, and only its people's keys and links work.

"Admin" is `authorization: Bearer <admin key>`, or the owner's key in `x-bottle-key` from the
home site. A page on any site the service knows may ask it from its own address (it answers
with `access-control-allow-origin` for those, and no others); a person's key works only from
their own site's pages. Nothing is listed without the admin key.

## How it was checked

`test/bottle.test.js` here covers the endpoint, the emails and the admin tool, and
`test/service.test.js` the service on its own, its folder and the commands. The button was
checked in a headless Chromium on Pixel Reel's pages (the first site it was on), under its
content security policy, on a 1280 x 657 window and as a 390 x 844 phone: choosing a part, writing, sending, and the screenshot matching what was on
the screen (scrolled, with the sticky bar at the top). Sites and people were checked the same way
with a stand-in client site at another address loading the button from a local service: the
personal link, a note with its screenshot, signing in at `/review` with a link from the outbox,
and the page of queues, on a phone and a wide screen. Speak was seen to appear in Chromium; nobody has dictated a note
with it yet. In headless Chromium standing in for Brave (`navigator.brave`) Speak is not
offered; standing in for a browser whose service fails as Brave's does (a `network` error) it
goes with the message, and stays gone on the next page; with the microphone refused it says so.

The links were checked the same way, as a 390 x 844 phone (and a 1280 x 800 window), with the
emails taken from the outbox: an invitation's card and its button, a sign-in link opened on a
phone already on (left on, the link unused), opened fresh, opened again once used (the button
stays on and says the link has run out), and opened with nothing kept (This link has run out, Get
a new link, then "Review Harbour Bakery", Check your email and Send again); a link pasted into a
tab already on the page; and the toast clear of the button. `decide()` in `bottle-ui.mjs` holds the choice made about a link and
a kept key, and the tests run it. Nobody has opened a link from a real inbox yet, through an
iPhone's mail app or a scanner such as Safe Links.

What a screenshot may not show: pictures from another site that does not allow it come out
blank. A note with no screenshot (it can fail on an unusual page) is still sent, with
everything else.
