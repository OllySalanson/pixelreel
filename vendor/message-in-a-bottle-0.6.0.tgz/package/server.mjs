// Message in a Bottle, the endpoint: one service for every site the button is on. It checks
// each person's key before the button shows, takes the notes they leave with it, keeps each one
// with its screenshot, sends the sign-in links asked for at a site's /review page, lets someone
// who gives a site's word at its /suggest page join its list (their notes wait aside until they
// are approved), and hands the
// notes to whoever looks after the sites, to work through and mark; what came of them goes to
// each person in one email at most an hour, and word of new ones to whoever looks after the
// sites the same way. Plain Node (node:http
// requests and responses), with no other packages but the screenshot maker it serves to the
// browser, so it can be dropped into any Node service. See README.md.
import { createHash, createHmac, randomBytes, timingSafeEqual } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { gzipSync } from 'node:zlib';

const VERSION = JSON.parse(readFileSync(new URL('./package.json', import.meta.url), 'utf8')).version;
import { arrivedMail, inviteMail, keyLink, newsMail, outbox, signInMail } from './mail.mjs';
import { addToClaude, answerAll, MCP_MAX_BYTES } from './mcp.mjs';
import { plainEmail, Said, same, ID as SITE_ID, Sites } from './sites.mjs';

/** The most one note may carry, screenshot and all. */
export const MAX_BYTES = 6 * 1024 * 1024;

/** The biggest screenshot kept, in bytes: a note with a bigger one is kept without it. */
export const MAX_SHOT = 4 * 1024 * 1024;

/** How long each field of a note may be, in characters. */
export const FIELDS = { note: 5000, url: 2000, title: 300, selector: 1000, text: 1000, tag: 40, browser: 500, outcome: 1000 };

/**
 * What a note can be, in the order a note goes through them: new when left; in-progress once
 * someone is on it; held when doing it would harm the site's SEO or brand, so it waits for a
 * decision; declined when it would be bad for the client; done when it is on the preview;
 * closed once its writer says it is right. A note from someone not approved yet is also
 * `waiting` (true) whatever its state, and is left out of every state's list until they are.
 */
export const STATES = ['new', 'in-progress', 'held', 'declined', 'done', 'closed'];

/** What the notes' first states are now. */
const OLD_STATES = { read: 'in-progress', asked: 'in-progress', fixed: 'done', dropped: 'declined' };

/** A note's id: when it was left, then a random part, so that ids sort by time. */
const ID = /^\d{8}-\d{6}-[0-9a-f]{8}$/;

const HEADERS = { 'x-content-type-options': 'nosniff', 'referrer-policy': 'no-referrer', 'x-robots-tag': 'noindex, nofollow, noarchive' };

const json = (res, status, value) => res.writeHead(status, { ...HEADERS, 'content-type': 'application/json', 'cache-control': 'no-store' }).end(JSON.stringify(value));

/** Counts in a sliding window, for each caller: hit() says whether one more is allowed, and counts it if so. */
class Window {
  constructor(most, ms, now) {
    Object.assign(this, { most, ms, now, seen: new Map() });
  }

  /** Whether `caller` has had as many as are allowed, counting nothing. */
  full(caller) {
    const at = this.now();
    return (this.seen.get(caller) ?? []).filter((t) => t > at - this.ms).length >= this.most;
  }

  hit(caller) {
    const at = this.now(), times = (this.seen.get(caller) ?? []).filter((t) => t > at - this.ms);
    if (times.length >= this.most) { this.seen.set(caller, times); return false; }
    this.seen.set(caller, [...times, at]);
    if (this.seen.size > 10000) for (const [who, ts] of this.seen) if (!ts.some((t) => t > at - this.ms)) this.seen.delete(who);
    return true;
  }
}

/**
 * The files a browser loads: the button, the rest of it once a key is in hand, the screenshot
 * maker, the recorder for a speech service, and the page of queues. `hear` is the speech
 * service's address, written into the button's code.
 */
function files({ hear = null } = {}) {
  const tagOf = (bytes) => createHash('sha256').update(bytes).digest('base64url').slice(0, 20);
  const file = (url, type, change = (bytes) => bytes) => {
    const bytes = change(readFileSync(url));
    return { bytes, type, gzip: gzipSync(bytes, { level: 9 }), tag: `"${tagOf(bytes)}"` };
  };
  const js = 'text/javascript; charset=utf-8';
  const heard = (bytes) => Buffer.from(bytes.toString('utf8').replace('const HEAR = null;', `const HEAR = ${JSON.stringify(hear)};`));
  const ui = file(new URL('./bottle-ui.mjs', import.meta.url), js, heard);
  // bottle.js asks for this very bottle-ui.mjs, so a browser holding one of them from before a change never runs it with the other
  const pinned = (bytes) => Buffer.from(bytes.toString('utf8').replace("'bottle-ui.mjs'", `'bottle-ui.mjs?v=${ui.tag.slice(1, -1)}'`));
  return {
    'bottle.js': file(new URL('./bottle.js', import.meta.url), js, pinned),
    'bottle-ui.mjs': ui,
    'shot.mjs': file(fileURLToPath(import.meta.resolve('modern-screenshot')), js),
    'hear-worklet.js': file(new URL('./hear-worklet.js', import.meta.url), js),
    'admin.mjs': file(new URL('./admin.mjs', import.meta.url), js),
    'admin.css': file(new URL('./admin.css', import.meta.url), 'text/css; charset=utf-8')
  };
}

/** A page of the bottle's own: nothing on it for a search engine, which is told to keep it out. */
const page = (title, body, prefix) => `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow, noarchive">
<meta name="referrer" content="no-referrer">
<title>${title}</title>
${body(prefix)}
</head>
<body></body>
</html>
`;
const ADMIN = (p) => `<link rel="stylesheet" href="${p}/admin.css">\n<script type="module" src="${p}/admin.mjs"></script>`;
const REVIEW = (p) => `<script src="${p}/bottle.js" data-review="" defer></script>`;
const PAGE_POLICY = "default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' data: blob:; connect-src 'self'; font-src 'self' data:; base-uri 'none'; form-action 'none'; frame-ancestors 'none'";

async function readBytes(req, max) {
  if (Number(req.headers['content-length']) > max) return null;
  const chunks = [];
  let size = 0;
  for await (const chunk of req.iterator({ destroyOnReturn: false })) {
    size += chunk.length;
    if (size > max) return null;
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

const readJson = async (req, max = 64 * 1024) => {
  try { return JSON.parse((await readBytes(req, max))?.toString('utf8') ?? ''); } catch { return null; }
};

const text = (value, most) => (typeof value === 'string' ? value.trim().slice(0, most) : '');
const count = (value) => (Number.isFinite(value) ? Math.round(value) : null);

/** The note a browser sent, made safe to keep: only the fields known, each cut to its length. Throws a message for the sender if there is no note. */
export function noteFrom(body, now = new Date()) {
  const note = text(body?.note, FIELDS.note);
  if (!note) throw new Error('Write what should change first.');
  const target = body.target ?? {}, view = body.viewport ?? {}, rect = target.rect ?? {};
  const stamp = now.toISOString().replace(/[-:T]/g, '').slice(0, 14);
  return {
    id: `${stamp.slice(0, 8)}-${stamp.slice(8)}-${randomBytes(4).toString('hex')}`,
    at: now.toISOString(),
    state: 'new',
    note,
    spoken: body.spoken === true,
    page: { url: text(body.page?.url, FIELDS.url), title: text(body.page?.title, FIELDS.title) },
    target: {
      whole: Boolean(target.whole),
      selector: text(target.selector, FIELDS.selector),
      tag: text(target.tag, FIELDS.tag),
      text: text(target.text, FIELDS.text),
      rect: { x: count(rect.x), y: count(rect.y), width: count(rect.width), height: count(rect.height) }
    },
    viewport: { width: count(view.width), height: count(view.height), scale: Number.isFinite(view.scale) ? view.scale : null, scrollX: count(view.scrollX), scrollY: count(view.scrollY) },
    browser: text(body.browser, FIELDS.browser),
    // the page's own settings, from the data- attributes on its <html>: how it looked
    settings: Object.fromEntries(Object.entries(body.settings && typeof body.settings === 'object' ? body.settings : {})
      .filter(([name, value]) => /^[a-z][a-z0-9-]{0,40}$/.test(name) && typeof value === 'string').slice(0, 20).map(([name, value]) => [name, value.slice(0, 100)])),
    shot: false,
    outcome: {},
    history: []
  };
}

/** The screenshot in a note, as JPEG bytes, or null if it carries none that is one. */
export function shotFrom(body) {
  const data = /^data:image\/jpeg;base64,([A-Za-z0-9+/=]+)$/.exec(typeof body?.shot === 'string' ? body.shot : '')?.[1];
  const bytes = data ? Buffer.from(data, 'base64') : null;
  return bytes && bytes.length > 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff ? bytes : null;
}

/**
 * What marking a note `state` says about it, from what was sent (`body`): for done, what was
 * done and how sure (`confidence`, 0 to 100) that it is what was meant; for held, the conflict
 * (with the site's SEO or brand) and the solution proposed; for declined, the `reason`, one or
 * two plain sentences beginning "We haven't". Throws a message saying what is missing.
 */
export function outcomeFrom(state, body = {}) {
  const say = (name) => text(body[name], FIELDS.outcome);
  if (state === 'done') {
    const what = say('what'), confidence = Number(body.confidence);
    if (!what) throw new Error('Say what was done, in "what".');
    if (!Number.isFinite(confidence) || confidence < 0 || confidence > 100) throw new Error('Say how sure it is what was meant, as "confidence" from 0 to 100.');
    return { what, confidence: Math.round(confidence), ...(say('conflict') ? { conflict: say('conflict') } : {}) };
  }
  if (state === 'held') {
    const conflict = say('conflict'), proposal = say('proposal');
    if (!conflict || !proposal) throw new Error('Say what it conflicts with, in "conflict", and the solution proposed, in "proposal".');
    return { conflict, proposal };
  }
  if (state === 'declined') {
    const reason = say('reason');
    if (!/^We (haven't|have not) /.test(reason)) throw new Error('Give the reason as "We haven\'t done this because...", in "reason".');
    if ((reason.match(/[.!?](\s|$)/g) ?? []).length > 2) throw new Error('Keep the reason to one or two sentences.');
    return { reason };
  }
  return {};
}

/**
 * The endpoint, mounted at `prefix` (default /bottle). Its handle(req, res) answers anything
 * under the prefix (and the `review` page, if there is one) and returns true, or returns
 * false having sent nothing.
 *
 * - `store`: where notes are kept, with put(key, bytes), get(key) (null when there is none)
 *   and folders(prefix), as service/store.mjs's are. Everything is under `bottles/`.
 * - `home` ({ id, name }) and `origins`: the site this service is part of, and its addresses.
 * - `key`: the service's own secret, a key for `owner` ({ id, name, email }), who is on the
 *   home site's list and may also see every site's queue on the admin page.
 * - `reader`: the admin key, for whoever looks after the sites: it adds sites and people and
 *   reads and marks the notes. Without one, only the owner's key does.
 * - `review`: the address of the home site's own sign-in page, such as /review, or null.
 * - `mail(message)`: sends an email ({ to, subject, text, replyTo }), resolving to { id }.
 *   Without one, each is kept in the store's outbox instead (mail.mjs) and nothing is sent.
 *   `from` signs them, and `replyTo` is where a reply to one goes.
 * - `notify`: the address told when new notes come in on a site (none by the owner's own key),
 *   in one email at most an hour for each site.
 * - `hear`: the address of a speech service that writes down a note said aloud where the
 *   browser cannot (Brave, Firefox), relative to the endpoint's own, such as /hear: POST mono
 *   16-bit samples at 16,000 a second, at most 12 seconds, answering { text }. It must take
 *   requests from every site's pages. Without one, Speak is only where the browser hears.
 * - `hook`: the signing secret of a Resend webhook (whsec_...), sent to POST <prefix>/resend,
 *   which says when an email bounced.
 * - `quiet`, `gap`: what came of a person's notes is emailed once nothing has been marked for
 *   them for `quiet` ms (10 minutes), and no sooner than `gap` (an hour) after the last; new
 *   notes are told the same way. `every`: how often to look (a minute; 0 never, as tests do,
 *   calling tell()).
 * - `caller(req)`: who is asking, for the rate limits (default: the connecting address).
 * - `perHour`, `perDay`: how many notes each person may leave an hour, and each site a day;
 *   `wrongPerHour`, how many wrong keys a caller may try; `signInsPerHour`, how many sign-in
 *   links a caller (or an address) may ask for; `visitsPerHour`, `visitsPerDay`: how many names a
 *   caller may give in an hour (on a preview, or with a site's word at its /suggest page), and
 *   how many people a site may take that way in a day. A wrong word counts as a wrong key, and
 *   `wrongWordsPerDay` (100) wrong words on one site, from anyone, stop it taking any that day.
 */
export function createBottle({ store, key = '', reader = '', origins = [], home = { id: 'home', name: 'This site' }, owner = { id: 'owner', name: 'Owner' },
  prefix = '/bottle', review = null, hear = null, mail = null, from = '', replyTo = '', notify = '', hook = '', caller = (req) => req.socket.remoteAddress ?? 'unknown',
  perHour = 30, perDay = 200, wrongPerHour = 10, wrongWordsPerDay = 100, signInsPerHour = 5, visitsPerHour = 5, visitsPerDay = 50, quiet = 10 * 60_000, gap = 3600_000, every = 60_000,
  log = () => {}, now = () => Date.now() } = {}) {
  const served = files({ hear });
  const ownerKey = key;
  /** The service's own address, for the connector's: the home site's, or the address it was asked at. */
  const connectorBase = (req) => (origins[0] ? new URL(origins[0]).origin : `${req.headers['x-forwarded-proto'] ?? 'http'}://${req.headers.host}`);
  const sites = new Sites({ store, home: { ...home, origins }, owner, ownerKey: key, now });
  const sender = mail ?? outbox(store, { now, log });
  const signs = { from, replyTo };
  const notes = new Window(perHour, 3600_000, now), noteCallers = new Window(perHour, 3600_000, now), daily = new Window(perDay, 86400_000, now);
  const wrong = new Window(wrongPerHour, 3600_000, now), signIns = new Window(signInsPerHour, 3600_000, now), signInsTo = new Window(3, 3600_000, now);
  const visits = new Window(visitsPerHour, 3600_000, now), visitsTo = new Window(visitsPerDay, 86400_000, now);
  const wrongWords = new Window(wrongWordsPerDay, 86400_000, now);
  const pending = new Set();

  /** Work done after the answer is sent, so how long it takes says nothing; idle() waits for it. */
  const later = (work) => {
    const job = Promise.resolve().then(work).catch((err) => log(`bottle: ${err.stack ?? err}`)).finally(() => pending.delete(job));
    pending.add(job);
    return job;
  };

  /** Runs `work` once everything given to it before is done, so two never change the same batch at once. */
  let line = Promise.resolve();
  const inTurn = (work) => {
    const job = line.then(work);
    line = job.catch(() => {});
    return job;
  };

  /**
   * Sends an email, and once it is sent (not before) keeps a note that it was, under
   * bottles/sent/: to whom, the subject, when and why, but no words of it, so no link. Resend's
   * id names it, so a webhook saying it bounced can find whose it was.
   */
  const deliver = async (message, about = {}) => {
    const done = await sender(message);
    if (!mail) return done;
    const at = new Date(now()).toISOString(), id = /^[\w-]{1,100}$/.test(done?.id ?? '') ? done.id : `${at.replace(/[-:T.Z]/g, '')}-${randomBytes(3).toString('hex')}`;
    await store.put(`bottles/sent/${id}/sent.json`, JSON.stringify({ id, at, to: message.to, subject: message.subject, ...about }, null, 2));
    return done;
  };

  // once emails really go, the outbox kept before (with links in it) goes
  if (mail && store.remove) later(async () => { if ((await store.folders('bottles/outbox')).length) { await store.remove('bottles/outbox'); log('bottle: the outbox was emptied, as emails are sent now'); } });

  /** Turns a caller away, or, if they keep getting keys wrong, away for an hour. */
  const refuse = (req, res, status, error) => {
    if (!wrong.hit(caller(req))) json(res, 429, { error: 'Too many wrong keys. Try again in an hour.' });
    else json(res, status, { error });
  };

  /** Whether the request comes from one of `site`'s pages (or from no page at all, as a script's does). */
  const fromSite = (req, site) => !req.headers.origin || site.origins.includes(req.headers.origin);

  /** The site a page names (x-bottle-site, from its line's data-site), where more than one site shares an address; '' when it names none. */
  const namedIn = (req) => String(req.headers['x-bottle-site'] ?? '');

  /** The site the page asking is on: the one it names, if that one is at the page's address, or else the one at its address. */
  const siteOf = async (req) => {
    const id = namedIn(req), origin = req.headers.origin;
    if (!id) return sites.at(origin);
    const site = await sites.get(id);
    return site && origin && site.origins.includes(origin) ? site : null;
  };

  /** Whether the request comes from `site`'s pages, and names no other site. */
  const onSite = (req, site) => fromSite(req, site) && (!namedIn(req) || namedIn(req) === site.id);

  /** Who the key in x-bottle-key is, if they may leave notes from here (and on the site the page names, if it names one); otherwise the caller is turned away and it is null. */
  const person = async (req, res) => {
    const found = await sites.who(req.headers['x-bottle-key']);
    if (found && onSite(req, found.site)) return found;
    refuse(req, res, 403, 'That key is not right.');
    return null;
  };

  /** Whether the request holds the admin key, or is from the owner on the home site. */
  const admin = async (req, res) => {
    const bearer = /^Bearer (.+)$/.exec(req.headers.authorization ?? '')?.[1];
    if (reader && same(bearer, reader)) return true;
    if (!bearer && req.headers['x-bottle-key']) {
      const found = await sites.who(req.headers['x-bottle-key']);
      if (found?.person.owner && fromSite(req, found.site)) return true;
    }
    if (!reader && !key) json(res, 404, { error: 'Notes are not read here.' });
    else refuse(req, res, 403, 'That key is not right.');
    return false;
  };

  const read = async (id) => {
    const bytes = await store.get(`bottles/${id}/note.json`);
    if (!bytes) return null;
    const note = JSON.parse(bytes);
    note.state = OLD_STATES[note.state] ?? note.state;
    note.site ??= home.id;
    note.outcome ??= {};
    return note;
  };
  const write = (note) => store.put(`bottles/${note.id}/note.json`, JSON.stringify(note, null, 2));

  const all = async () => {
    const ids = (await store.folders('bottles')).filter((id) => ID.test(id)).sort();
    const found = [];
    for (let i = 0; i < ids.length; i += 8) found.push(...(await Promise.all(ids.slice(i, i + 8).map(read))));
    // in the order they were left: ids are by the second, so two left in the same second go by when
    return found.filter(Boolean).sort((a, b) => a.at.localeCompare(b.at) || a.id.localeCompare(b.id));
  };

  const sendFile = (req, res, name) => {
    const file = served[name];
    const headers = {
      ...HEADERS, 'content-type': file.type, 'cache-control': 'public, max-age=3600', etag: file.tag, vary: 'accept-encoding',
      // other sites' pages load the button from here
      'access-control-allow-origin': '*', 'cross-origin-resource-policy': 'cross-origin'
    };
    if (req.headers['if-none-match'] === file.tag) { res.writeHead(304, headers).end(); return; }
    const gzip = /\bgzip\b/.test(String(req.headers['accept-encoding'] ?? ''));
    const body = gzip ? file.gzip : file.bytes;
    res.writeHead(200, { ...headers, ...(gzip ? { 'content-encoding': 'gzip' } : {}), 'content-length': body.length }).end(req.method === 'HEAD' ? undefined : body);
  };

  const sendPage = (req, res, html) => {
    res.writeHead(200, { ...HEADERS, 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store', 'content-security-policy': PAGE_POLICY })
      .end(req.method === 'HEAD' ? undefined : html);
  };

  /**
   * Whether the key is right. A link's code is not a key: it answers 409 { code: true }, and is
   * swapped for a key of the person's own (which the browser keeps instead) only when asked to
   * with { "use": true }, which the page sends once its button is pressed. So a mail scanner
   * that opens a link, even one that runs its script, does not use it up.
   */
  async function check(req, res) {
    const given = req.headers['x-bottle-key'];
    const found = await sites.who(given);
    if (found && onSite(req, found.site)) { json(res, 200, { ok: true }); return; }
    const code = !found && (await sites.peek(given));
    if (code && onSite(req, code.site)) {
      if ((await readJson(req))?.use !== true) { json(res, 409, { code: true, error: 'That is a link\'s code: press the button to use it.' }); return; }
      const redeemed = await sites.redeem(given);
      if (redeemed) { log(`bottle: ${redeemed.person.id} switched the button on, on ${redeemed.site.id}, by ${code.kind}`); json(res, 200, { ok: true, key: redeemed.key }); return; }
    }
    refuse(req, res, 403, 'That key is not right.');
  }

  /** The name of the site a page is on, for its /review page to say. */
  async function siteName(req, res) {
    const site = await siteOf(req);
    if (!site) { json(res, 403, { error: 'Only from a site the notes are taken for.' }); return; }
    json(res, 200, { name: site.name, ...(site.preview ? { preview: true } : {}), ...(site.word ? { word: true } : {}) });
  }

  /** Someone on a preview's page gives their name, and is given a key of their own. */
  async function visit(req, res) {
    const site = await siteOf(req);
    if (!site?.preview) { json(res, 403, { error: 'Only from a preview the notes are taken for.' }); return; }
    if (!visits.hit(caller(req)) || !visitsTo.hit(site.id)) { json(res, 429, { error: 'Try again in a while.' }); return; }
    try {
      const made = await sites.addVisitor(site.id, (await readJson(req))?.name);
      log(`bottle: ${made.person.id} switched the button on, on ${site.id}, by giving their name`);
      json(res, 201, { key: made.key, name: made.person.name });
    } catch (err) {
      if (!(err instanceof Said)) throw err;
      json(res, 400, { error: err.message });
    }
  }

  /**
   * Someone at a live site's /suggest page joins its list: { by: 'word', word, name }, the
   * site's word and their name, gives 201 { key, name }, a key of their own for a year. They
   * wait to be approved, and their notes with them. A wrong word counts as a wrong key, so a
   * caller who keeps guessing is turned away for an hour. `by` names the way they join, so
   * another (a code sent to their phone, say) can be added beside the word.
   */
  async function join(req, res) {
    const site = await siteOf(req);
    if (!site?.word) { json(res, 403, { error: 'This site takes no word.' }); return; }
    const body = await readJson(req);
    if (body?.by !== 'word') { json(res, 400, { error: 'Send { "by": "word", "word": ..., "name": ... }.' }); return; }
    // a caller turned away is turned away whatever they give, so guessing on finds nothing; and
    // a site given too many wrong words in a day takes none, from anyone, until the day is out
    if (wrong.full(caller(req)) || wrongWords.full(site.id)) { json(res, 429, { error: 'Too many wrong words. Try again later.' }); return; }
    if (visits.full(caller(req)) || visitsTo.full(site.id)) { json(res, 429, { error: 'Try again in a while.' }); return; }
    let made;
    try { made = await sites.joinByWord(site.id, { word: body.word, name: body.name }); } catch (err) {
      if (!(err instanceof Said)) throw err;
      json(res, 400, { error: err.message });
      return;
    }
    if (!made) { wrongWords.hit(site.id); refuse(req, res, 403, 'That is not the word.'); return; }
    visits.hit(caller(req));
    visitsTo.hit(site.id);
    log(`bottle: ${made.person.id} switched the button on, on ${site.id}, by giving its word`);
    json(res, 201, { key: made.key, name: made.person.name });
  }

  /**
   * Adds `id` to the batch kept in `file` ({ notes, added, last }), which tell() sends once
   * nothing has been added for `quiet` and `gap` has gone since the last was sent.
   */
  const batch = (file, id) => inTurn(async () => {
    const kept = JSON.parse((await store.get(file)) ?? 'null') ?? { notes: [], last: null };
    if (!kept.notes.includes(id)) kept.notes.push(id);
    kept.added = now();
    await store.put(file, JSON.stringify(kept));
    soonest = Math.min(soonest, Math.max(kept.added + quiet, (kept.last ?? -Infinity) + gap));
  });
  const newsFile = (site, person) => `bottles/news/${site}/${person}/news.json`;
  const arrivedFile = (site) => `bottles/arrived/${site}/arrived.json`;
  /** When tell() next has something to send; 0 until it has looked once. */
  let soonest = 0;

  /**
   * Sends every batch that is due: to each person, what came of their notes since the last
   * email (a note is marked told only once that is sent, so one that fails goes next time), and
   * to `notify`, the notes that came in on each site. A person turned off is sent nothing, and
   * their news waits until they are on again.
   */
  const tell = () => inTurn(async () => {
    const at = now();
    let next = Infinity;
    const due = (kept) => Math.max(kept.added + quiet, (kept.last ?? -Infinity) + gap);
    const each = async (file, send) => {
      const kept = JSON.parse((await store.get(file)) ?? 'null');
      if (!kept?.notes?.length) return;
      if (at < due(kept)) { next = Math.min(next, due(kept)); return; }
      try {
        if ((await send(kept)) === false) return;
      } catch (err) {
        log(`bottle: ${file} could not be sent, and is tried again in ${Math.round(quiet / 60_000)} minutes: ${err.message ?? err}`);
        next = Math.min(next, at + quiet);
        return;
      }
      await store.put(file, JSON.stringify({ notes: [], added: kept.added, last: kept.last }));
    };
    for (const siteId of await store.folders('bottles/news')) {
      for (const personId of await store.folders(`bottles/news/${siteId}`)) {
        await each(newsFile(siteId, personId), async (kept) => {
          const found = await sites.person(siteId, personId);
          if (found && (found.person.on === false || !found.person.email)) return false;
          const notes = (await Promise.all(kept.notes.map(read))).filter((n) => n && !n.told && (n.state === 'done' || n.state === 'declined'));
          if (!found || !notes.length) return;
          await deliver(newsMail({ site: found.site, person: found.person, notes, ...signs }), { kind: 'news', site: siteId, person: personId, notes: notes.map((n) => n.id) });
          // read again, as a note may have been marked while the email went
          for (const n of notes) { const fresh = await read(n.id); if (fresh) await write({ ...fresh, told: new Date(at).toISOString() }); }
          kept.last = at;
          log(`bottle: ${personId} on ${siteId} was told what came of ${notes.length} notes`);
        });
      }
    }
    for (const siteId of await store.folders('bottles/arrived')) {
      await each(arrivedFile(siteId), async (kept) => {
        const site = await sites.get(siteId), notes = (await Promise.all(kept.notes.map(read))).filter(Boolean);
        if (!site || !notes.length || !notify) return;
        await deliver(arrivedMail({ to: notify, site, notes, queue: `${(origins[0] ?? '').replace(/\/$/, '')}${prefix}/admin#site=${encodeURIComponent(siteId)}` }), { kind: 'arrived', site: siteId });
        kept.last = at;
      });
    }
    soonest = next;
  });
  if (every > 0) setInterval(() => { if (now() >= soonest) tell().catch((err) => log(`bottle: ${err.stack ?? err}`)); }, every).unref();

  /** A Resend webhook (signed as Svix signs them): a bounce or complaint is kept on the person it was for. */
  async function resendHook(req, res) {
    const bytes = hook ? await readBytes(req, 256 * 1024) : null;
    const id = req.headers['svix-id'], stamp = Number(req.headers['svix-timestamp']);
    const secret = Buffer.from(String(hook).replace(/^whsec_/, ''), 'base64');
    const signed = bytes && typeof id === 'string' && Number.isFinite(stamp) && Math.abs(now() / 1000 - stamp) < 300
      && String(req.headers['svix-signature'] ?? '').split(' ').some((part) => {
        const [version, sig] = part.split(',');
        const want = createHmac('sha256', secret).update(`${id}.${req.headers['svix-timestamp']}.`).update(bytes).digest();
        const given = Buffer.from(sig ?? '', 'base64');
        return version === 'v1' && given.length === want.length && timingSafeEqual(given, want);
      });
    if (!signed) { json(res, hook ? 400 : 404, { error: hook ? 'That is not signed.' : 'There is nothing here.' }); return; }
    let event;
    try { event = JSON.parse(bytes.toString('utf8')); } catch { json(res, 400, { error: 'That could not be read.' }); return; }
    const state = { 'email.bounced': 'bounced', 'email.complained': 'complained', 'email.delivered': 'delivered' }[event?.type];
    const sentId = String(event?.data?.email_id ?? '');
    const sent = state && /^[\w-]{1,100}$/.test(sentId) ? JSON.parse((await store.get(`bottles/sent/${sentId}/sent.json`)) ?? 'null') : null;
    if (sent?.site && sent.person) {
      await sites.mailed(sent.site, sent.person, { kind: sent.kind, at: new Date(now()).toISOString(), state });
      if (state !== 'delivered') log(`bottle: an email to ${sent.person} on ${sent.site} ${state}: "${sent.subject}"`);
    }
    json(res, 200, { ok: true });
  }

  async function leave(req, res) {
    const found = await person(req, res);
    if (!found) return;
    const { site, person: who } = found;
    if (!notes.hit(`${site.id}/${who.id}`) || !noteCallers.hit(caller(req)) || !daily.hit(site.id)) { json(res, 429, { error: 'That is a lot of suggestions. Try again in a while.' }); return; }
    const bytes = await readBytes(req, MAX_BYTES);
    if (!bytes) {
      res.setHeader('connection', 'close');
      res.once('finish', () => req.socket.destroy());
      json(res, 413, { error: 'That is too big to send.' });
      return;
    }
    let body, note;
    try {
      body = JSON.parse(bytes.toString('utf8'));
      note = noteFrom(body, new Date(now()));
    } catch (err) {
      json(res, 400, { error: err instanceof SyntaxError ? 'That could not be read.' : err.message });
      return;
    }
    await keepNote(site, who, note, shotFrom(body));
    json(res, 201, { id: note.id });
  }

  /** Keeps a note `who` left on `site` (with its screenshot, if any), and tells whoever looks after the sites in time. The button's notes and Claude's both come through here. */
  async function keepNote(site, who, note, shot = null) {
    Object.assign(note, { site: site.id, person: who.id, by: who.name, ...(who.approved === false ? { waiting: true } : {}) });
    if (shot && shot.length <= MAX_SHOT) {
      await store.put(`bottles/${note.id}/shot.jpg`, shot);
      note.shot = true;
    } else if (shot) log(`bottle: a screenshot of ${shot.length} bytes was too big to keep, ${note.id}`);
    await write(note);
    log(`bottle: a note was left on ${site.id}${note.via ? ` from ${note.via}` : ''}, ${note.id}`);
    if (notify && !who.owner) later(() => batch(arrivedFile(site.id), note.id));
  }

  /** Where a page named to Claude is: an address on the site, a path on it, or the name of a page (kept as its title). */
  const pageFor = (site, page) => {
    const home = site.page ?? site.origins[0] ?? '';
    const named = page.trim().slice(0, FIELDS.url);
    if (!named) return { url: home, title: '' };
    try {
      const url = new URL(named, site.origins[0]);
      if (site.origins.includes(url.origin) && (/^https?:\/\//.test(named) || named.startsWith('/'))) return { url: url.href, title: '' };
    } catch { /* not an address: the name of a page */ }
    return { url: home, title: named.slice(0, FIELDS.title) };
  };

  /** A suggestion sent from Claude by the person a connector's key is theirs: kept as the button keeps a note, marked as from Claude. */
  async function suggestFromClaude({ site, person: who }, { change, page }) {
    // the words are checked first, so a go with nothing in it does not count against the limits
    const note = noteFrom({ note: change, page: pageFor(site, page), target: { whole: true, tag: 'html' }, browser: 'Claude' }, new Date(now()));
    if (!notes.hit(`${site.id}/${who.id}`) || !daily.hit(site.id)) throw new Error('That is a lot of suggestions. Try again in a while.');
    note.via = 'claude';
    await keepNote(site, who, note);
    return `Sent. It is in the ${site.name} queue of suggestions, from ${who.name}, marked as sent from Claude. ${owner.name} will look at it; nothing on the site changes until then.`;
  }

  /**
   * The connector, at <prefix>/mcp/<key> (mcp.mjs). Claude's servers ask it, never a browser, so
   * a request from a page is turned away. A wrong key counts against the caller as the button's do.
   */
  async function connector(req, res, key) {
    if (req.headers.origin) { json(res, 403, { error: 'Only Claude asks here.' }); return; }
    if (req.method !== 'POST') { res.setHeader('allow', 'POST'); json(res, 405, { error: 'Ask with POST.' }); return; }
    // the service's own secret never goes in an address
    const found = key && !(ownerKey && same(key, ownerKey)) ? await sites.who(key) : null;
    if (!found) { refuse(req, res, 404, 'There is nothing here.'); return; }
    const bytes = await readBytes(req, MCP_MAX_BYTES);
    if (!bytes) { json(res, 413, { error: 'That is too big.' }); return; }
    let body;
    try { body = JSON.parse(bytes.toString('utf8')); } catch { json(res, 400, { jsonrpc: '2.0', id: null, error: { code: -32700, message: 'That is not JSON.' } }); return; }
    const answered = await answerAll(body, { who: found, owner: owner.name, version: VERSION, suggest: (args) => suggestFromClaude(found, args) });
    if (answered === null) { res.writeHead(202, HEADERS).end(); return; }
    json(res, 200, answered);
  }

  async function signIn(req, res) {
    const site = await siteOf(req);
    if (!site) { json(res, 403, { error: 'Only from a site the notes are taken for.' }); return; }
    const body = await readJson(req);
    const email = plainEmail(body?.email);
    if (!email || email.length > 254) { json(res, 400, { error: 'Give your email address.' }); return; }
    if (!signIns.hit(caller(req)) || !signInsTo.hit(`${site.id}/${email}`)) { json(res, 429, { error: 'Try again in a while.' }); return; }
    // the same answer, as soon, whether or not the address is on the list: only its owner learns which, from their email
    json(res, 202, { ok: true });
    later(async () => {
      const made = await sites.code(site.id, email);
      if (!made) return;
      if (!made.code) { log(`bottle: ${made.person.id} on ${site.id} has been sent as many sign-in links as a day allows`); return; }
      await deliver(signInMail({ site: made.site, person: made.person, code: made.code, ...signs }), { kind: 'sign-in', site: site.id, person: made.person.id });
      log(`bottle: a sign-in link was sent for ${made.person.id} on ${site.id}`);
    });
  }

  /** Each site with how many of its notes are in each state. */
  async function queues() {
    const found = await all(), list = await sites.all();
    return list.map((site) => {
      const counts = Object.fromEntries([...STATES, 'waiting'].map((s) => [s, 0]));
      for (const n of found) if (n.site === site.id) { if (n.waiting) counts.waiting++; else if (counts[n.state] !== undefined) counts[n.state]++; }
      return { ...Sites.shown(site), counts };
    });
  }

  async function mark(req, res, id) {
    const note = await read(id);
    if (!note) { json(res, 404, { error: 'There is no such note.' }); return; }
    const body = await readJson(req);
    if (!STATES.includes(body?.state)) { json(res, 400, { error: `Send { "state": one of ${STATES.join(', ')} } and what goes with it.` }); return; }
    let outcome;
    try { outcome = outcomeFrom(body.state, body); } catch (err) { json(res, 400, { error: err.message }); return; }
    const was = note.state, answer = text(body.answer, FIELDS.note);
    note.state = body.state;
    note.outcome = { ...note.outcome, ...outcome };
    note.history = [...note.history, { at: new Date(now()).toISOString(), state: body.state, ...outcome, ...(answer ? { answer } : {}) }];
    await write(note);
    // its writer hears what came of it, done or declined, once, in the next email of news for them
    if ((note.state === 'done' || note.state === 'declined') && was !== note.state && !note.told && note.person) {
      const found = await sites.person(note.site, note.person);
      if (found && !found.person.owner) await batch(newsFile(note.site, note.person), note.id);
    }
    json(res, 200, note);
  }

  /** Approves someone who joined by themselves, once: their notes waiting aside join the queue, as if just left. */
  async function approve(siteId, personId) {
    const approved = await sites.approve(siteId, personId);
    for (const n of await all()) if (n.waiting && n.site === siteId && n.person === personId) { delete n.waiting; await write(n); }
    log(`bottle: ${personId} on ${siteId} was approved`);
    return approved;
  }

  /** The admin's requests about sites and the people on them. */
  async function people(req, res, parts) {
    const [siteId, , personId, act] = parts;
    if (parts.includes('') || parts.length > 4) { json(res, 404, { error: 'There is nothing here.' }); return; }
    const method = req.method;
    try {
      if (!siteId && method === 'GET') { json(res, 200, { sites: await queues() }); return; }
      if (!siteId && method === 'POST') { const body = await readJson(req); json(res, 201, Sites.shown(await sites.add(body ?? {}))); return; }
      if (!SITE_ID.test(siteId)) { json(res, 404, { error: 'There is no such site.' }); return; }
      if (parts.length === 1 && method === 'GET') {
        const site = await sites.get(siteId);
        json(res, site ? 200 : 404, site ? Sites.shown(site) : { error: 'There is no such site.' });
        return;
      }
      if (parts[1] !== 'people') { json(res, 404, { error: 'There is nothing here.' }); return; }
      if (!personId && method === 'POST') {
        const body = await readJson(req) ?? {};
        const { person: added, code } = await sites.addPerson(siteId, body);
        json(res, 201, { person: added, link: keyLink(await sites.get(siteId), code) });
        return;
      }
      const found = personId && (await sites.person(siteId, personId));
      if (!found) { json(res, 404, { error: 'There is nobody by that id on that site\'s list.' }); return; }
      if (!act && method === 'PATCH') {
        const body = await readJson(req);
        if (typeof body?.email === 'string') { json(res, 200, await sites.email(siteId, personId, body.email)); return; }
        if (body?.approved === true) { json(res, 200, await approve(siteId, personId)); return; }
        if (typeof body?.on !== 'boolean') { json(res, 400, { error: 'Send { "on": true }, { "on": false }, { "approved": true } or { "email": ... }.' }); return; }
        const turned = await sites.turn(siteId, personId, body.on);
        // news kept for them while they were off goes in the next email
        if (turned.on) soonest = 0;
        json(res, 200, turned);
        return;
      }
      // an address of their own for Claude, with a key of its own in it: added once as a connector in Claude (mcp.mjs)
      if (act === 'claude' && method === 'POST' && !found.person.owner) {
        if (found.person.on === false) { json(res, 400, { error: `${found.person.name} is off: turn them on first.` }); return; }
        const made = await sites.newKey(siteId, personId, 'claude', found.person.era ?? 0);
        const address = `${connectorBase(req)}${prefix}/mcp/${made}`;
        json(res, 200, { address, add: addToClaude(found.site, address) });
        return;
      }
      if ((act === 'link' || act === 'invite') && method === 'POST' && !found.person.owner) {
        const body = await readJson(req) ?? {};
        const path = review ?? '/review';
        // a preview to someone else carries no link, so a wrong address is sent nothing that works
        if (act === 'invite' && body.to !== undefined) {
          const to = plainEmail(body.to);
          if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(to)) { json(res, 400, { error: 'Give the address to send the preview to.' }); return; }
          await deliver({ ...inviteMail({ site: found.site, person: found.person, code: null, ...signs, path }), to }, { kind: 'preview', site: siteId });
          json(res, 200, { to, sent: Boolean(mail), preview: true });
          return;
        }
        if (act === 'invite' && !found.person.email) { json(res, 400, { error: `${found.person.name} has no email address: give them a link instead (person link).` }); return; }
        const { site, person: invited, code } = await sites.invite(siteId, personId);
        if (act === 'link') { json(res, 200, { link: keyLink(site, code) }); return; }
        await deliver(inviteMail({ site, person: invited, code, ...signs, path }), { kind: 'invitation', site: siteId, person: personId });
        await sites.mailed(siteId, personId, { kind: 'invitation', at: new Date(now()).toISOString(), state: mail ? 'sent' : 'kept' });
        json(res, 200, { to: invited.email, sent: Boolean(mail) });
        return;
      }
      json(res, 404, { error: 'There is nothing here.' });
    } catch (err) {
      if (err instanceof Said) json(res, 400, { error: err.message });
      else throw err;
    }
  }

  async function mails(res) {
    const ids = (await store.folders('bottles/outbox')).sort().reverse().slice(0, 50);
    const found = await Promise.all(ids.map(async (id) => JSON.parse((await store.get(`bottles/outbox/${id}/mail.json`)) ?? 'null')));
    json(res, 200, { mails: found.filter(Boolean) });
  }

  /** Lets a page on any site the notes are taken for reach the endpoint from its own address. */
  const welcome = async (req, res) => {
    const origin = req.headers.origin;
    if (!origin || !(await sites.allowed(origin))) return false;
    res.setHeader('access-control-allow-origin', origin);
    res.setHeader('vary', 'origin');
    return true;
  };

  async function handle(req, res) {
    const url = new URL(req.url, 'http://localhost'), path = url.pathname, method = req.method;
    const reading = method === 'GET' || method === 'HEAD';
    if (review && path.replace(/\/$/, '') === review && reading) { sendPage(req, res, page('Review', REVIEW, prefix)); return true; }
    if (path !== prefix && !path.startsWith(`${prefix}/`)) return false;
    const rest = path.slice(prefix.length + 1);
    try {
      if (reading && served[rest]) { sendFile(req, res, rest); return true; }
      // the page of queues, at the prefix itself (a site's /bottle) as well as /bottle/admin
      if (reading && (rest === 'admin' || rest === '')) { sendPage(req, res, page('Queues', ADMIN, prefix)); return true; }
      const asked = /^mcp\/([\w-]{8,200})$/.exec(rest);
      if (asked || rest === 'mcp') { await connector(req, res, asked?.[1] ?? ''); return true; }
      if (method === 'OPTIONS') {
        if (await welcome(req, res)) {
          res.writeHead(204, { ...HEADERS, 'access-control-allow-methods': 'GET, POST', 'access-control-allow-headers': 'content-type, x-bottle-key, x-bottle-site', 'access-control-max-age': '600' }).end();
        } else json(res, 403, { error: 'Only from a site the notes are taken for.' });
        return true;
      }
      // what a page asks, from its own site or another
      if (['check', 'join', 'notes', 'signin', 'site', 'visit'].includes(rest)) await welcome(req, res);
      if (rest === 'check' && method === 'POST') { await check(req, res); return true; }
      if (rest === 'site' && method === 'POST') { await siteName(req, res); return true; }
      if (rest === 'resend' && method === 'POST') { await resendHook(req, res); return true; }
      if (rest === 'signin' && method === 'POST') { await signIn(req, res); return true; }
      if (rest === 'visit' && method === 'POST') { await visit(req, res); return true; }
      if (rest === 'join' && method === 'POST') { await join(req, res); return true; }
      if (rest === 'notes' && method === 'POST') { await leave(req, res); return true; }

      // what only whoever looks after the sites may ask
      if (rest === 'notes' && method === 'GET') {
        if (!(await admin(req, res))) return true;
        const state = url.searchParams.get('state'), site = url.searchParams.get('site');
        if (state && !['all', 'open', 'waiting'].includes(state) && !STATES.includes(state)) { json(res, 400, { error: `state is one of ${STATES.join(', ')}, open, waiting or all` }); return true; }
        const open = ['new', 'in-progress', 'held'];
        // a note from someone not approved yet is only in waiting (and all)
        const wanted = (n) => state === 'all' || (state === 'waiting' ? n.waiting === true : !n.waiting && (state === 'open' ? open.includes(n.state) : n.state === (state ?? 'new')));
        json(res, 200, { notes: (await all()).filter((n) => wanted(n) && (!site || n.site === site)) });
        return true;
      }
      if (rest === 'sites' || rest.startsWith('sites/')) {
        if (await admin(req, res)) await people(req, res, rest.split('/').slice(1));
        return true;
      }
      if (rest === 'outbox' && reading) { if (await admin(req, res)) await mails(res); return true; }
      const one = /^notes\/([^/]+)(\/shot\.jpg)?$/.exec(rest);
      if (one && ID.test(one[1])) {
        if (!(await admin(req, res))) return true;
        if (reading && one[2]) {
          const shot = await store.get(`bottles/${one[1]}/shot.jpg`);
          if (shot) res.writeHead(200, { ...HEADERS, 'content-type': 'image/jpeg', 'cache-control': 'no-store', 'content-length': shot.length }).end(shot);
          else json(res, 404, { error: 'That note has no screenshot.' });
          return true;
        }
        if (reading) { const note = await read(one[1]); json(res, note ? 200 : 404, note ?? { error: 'There is no such note.' }); return true; }
        if (method === 'PATCH' && !one[2]) { await mark(req, res, one[1]); return true; }
      }
      json(res, 404, { error: 'There is nothing here.' });
    } catch (err) {
      log(`bottle: ${method} ${path}: ${err.stack ?? err}`);
      if (!res.headersSent) json(res, 500, { error: 'Something went wrong. Try again in a while.' });
    }
    return true;
  }

  /** Resolves once the work begun after an answer (an email to send) is done. */
  const idle = async () => { while (pending.size) await Promise.all(pending); await line; };

  return { handle, idle, tell, sites };
}
