// Message in a Bottle, the part every page loads: it does nothing at all unless this browser
// holds a key (kept once a link from an email has been opened and its button pressed, or once
// signed in at the site's /review page) or the page was opened from such a link
// (#bottle=<code>, or ?bottle=<code> in links sent before), so no other visitor ever sees the
// button. Then it loads the rest (bottle-ui.mjs), which checks with the service before showing
// anything. #bottle=off forgets the key again. On a live site's /suggest page (its line says
// data-suggest), whoever was told the site's word gives it with their name to switch the button
// on for that browser. On a site that is a preview, its line says
// data-preview and the button is there for anyone (bottle-ui.mjs asks the service first). Where
// more than one site lives at one address (client previews in folders of an agency's site), the
// line names its site with data-site="<id>", and each site's key is kept apart. A plain
// script, so any page on any site can load it: <script src="https://<the service>/bottle/bottle.js" defer></script>
(() => {
  const script = document.currentScript;
  const site = script?.getAttribute('data-site') || null;
  const STORE = site ? `bottle-key:${site}` : 'bottle-key';
  // a link opened in a tab already on its page changes only the part after #, which loads nothing: load it, so it is seen
  addEventListener('hashchange', () => { if (new URLSearchParams(location.hash.slice(1)).has('bottle')) location.reload(); });
  const base = new URL('.', script?.src ?? location.href);
  const address = new URL(location.href);
  const hash = new URLSearchParams(address.hash.slice(1));
  const asked = hash.get('bottle') ?? address.searchParams.get('bottle');
  let kept = null, legacy = null;
  try {
    kept = localStorage.getItem(STORE);
    // a line that names its site now, where it named none before: the key kept then is taken up
    // (kept under the site's own name too; if it is not this site's, the service refuses it and
    // only that copy is forgotten), and the notes it left unsent with it
    if (site && !kept && localStorage.getItem('bottle-key')) {
      kept = localStorage.getItem('bottle-key');
      localStorage.setItem(STORE, kept);
      legacy = 'bottle-key';
    }
  } catch { /* no storage here: the link works for this visit only */ }
  if (asked !== null) {
    // the code comes out of the address at once, so it is not in a link copied from here, in a screenshot, or seen by the page's own scripts later
    address.searchParams.delete('bottle');
    if (hash.has('bottle')) {
      hash.delete('bottle');
      address.hash = hash.toString();
    }
    history.replaceState(history.state, '', address);
  }
  if (asked === 'off') {
    try { localStorage.removeItem(STORE); } catch { /* nothing kept */ }
    return;
  }
  const link = asked || null;
  const load = (then) => import(new URL('bottle-ui.mjs', base).href).then(then).catch((err) => console.error('bottle:', err));
  // the site's /review page (its line has data-review), where someone on its list asks for a link to switch the button on,
  // and its /suggest page (data-suggest), where someone gives the site's word and their name
  const signIn = script?.hasAttribute('data-review') ? 'review' : script?.hasAttribute('data-suggest') ? 'suggest' : null;
  if (signIn) {
    if (!document.querySelector('meta[name="robots"]')) document.head.append(Object.assign(document.createElement('meta'), { name: 'robots', content: 'noindex, nofollow' }));
    load((ui) => ui[signIn]({ link, kept, base, store: STORE, site }));
    return;
  }
  // a site that is a preview (data-preview) offers the button to anyone, who gives their name once
  const preview = Boolean(script?.hasAttribute('data-preview'));
  if (!link && !kept) {
    if (preview) load((ui) => ui.visit({ base, store: STORE, site }));
    return;
  }
  load((ui) => ui.start({ link, kept, base, store: STORE, preview, site, legacy }));
})();
