// Message in a Bottle, the button and what it opens: loaded by bottle.js only when this
// browser holds a key or was opened from a link, and shown only once the service says the key
// is right. A link's code switches the button on only once its button is pressed, and a link
// that has run out says so, never taking a key this browser already holds that works. Press the
// button, click the part of the page the note is about (or choose the whole page), write or
// say the note, send. A page may have a Note button of its own instead (data-bottle-note), and
// may mark parts no note can be about (data-bottle-skip): they are never outlined or chosen. With
// the note go a screenshot of what was on the screen with that part outlined, the address, a CSS selector and the words of that part, the
// window's size and the browser. On a site's /review page it draws the box where someone on
// the site's list asks for a link instead (review()), and on its /suggest page the box where
// someone gives the site's word and their name (suggest()). Everything it draws is in a shadow root, styled through
// adoptedStyleSheets, so the page's own styles cannot reach it and a strict content security
// policy (no inline styles or scripts) does not stop it.

const CSS = `
:host { all: initial; }
* { box-sizing: border-box; }
.dock button, .banner, .panel, .toast, .card, .notice {
  position: fixed; z-index: 2147483647; font: 18px/1.5 system-ui, -apple-system, "Segoe UI", sans-serif;
  color: #f8f7dd; background: #13203a; border: 3px solid #ffcc4d; border-radius: 10px;
  box-shadow: 0 6px 24px rgba(0, 0, 0, 0.45);
}
button { font: inherit; cursor: pointer; border-radius: 8px; min-height: 44px; padding: 6px 16px; border: 2px solid #ffcc4d; background: #0b1220; color: #f8f7dd; }
button:hover { background: #1d2d50; }
button:focus-visible, textarea:focus-visible { outline: 3px solid #7fd4ff; outline-offset: 2px; }
button.go { background: #ffcc4d; color: #0b1220; font-weight: 700; }
button.go:hover { background: #ffe08a; }
button:disabled { opacity: 0.6; cursor: wait; }
.dock {
  position: fixed; z-index: 2147483647; left: max(12px, env(safe-area-inset-left)); bottom: max(12px, env(safe-area-inset-bottom));
  display: flex; gap: 8px;
}
.dock button { position: static; display: flex; align-items: center; gap: 8px; padding: 6px 14px; min-height: 48px; font-weight: 700; }
.dock .bottle { padding-left: 10px; }
.dock button:hover { background: #1d2d50; }
.bottle svg { width: 26px; height: 26px; flex: none; }
.banner {
  left: 50%; bottom: max(12px, env(safe-area-inset-bottom)); transform: translateX(-50%); width: max-content; max-width: calc(100vw - 24px);
  display: flex; flex-wrap: wrap; align-items: center; justify-content: center; gap: 10px 12px; padding: 10px 14px;
}
.banner p { margin: 0; font-weight: 700; }
.ring {
  position: fixed; z-index: 2147483646; pointer-events: none; border: 3px solid #ffcc4d; border-radius: 4px;
  box-shadow: 0 0 0 3px rgba(11, 18, 32, 0.85), 0 0 0 9999px rgba(11, 18, 32, 0.18); transition: all 60ms linear;
}
.ring span {
  position: absolute; left: -3px; bottom: 100%; margin-bottom: 3px; padding: 0 8px; border-radius: 4px;
  font: 700 15px/1.6 system-ui, -apple-system, "Segoe UI", sans-serif; color: #0b1220; background: #ffcc4d; white-space: nowrap;
}
.ring.low span { bottom: auto; top: 100%; margin: 3px 0 0; }
.panel {
  left: 50%; transform: translateX(-50%); width: min(36rem, calc(100vw - 24px)); padding: 14px 16px 16px;
  display: flex; flex-direction: column; gap: 10px; bottom: max(12px, env(safe-area-inset-bottom));
}
.panel.up { bottom: auto; top: 12px; }
/* on a wide screen the box stands beside the part chosen, not over it */
@media (min-width: 860px) {
  .panel { width: min(26rem, 40vw); transform: none; left: auto; right: max(12px, env(safe-area-inset-right)); }
  .panel.left { right: auto; left: max(12px, env(safe-area-inset-left)); }
  .panel.up { bottom: max(12px, env(safe-area-inset-bottom)); top: auto; }
}
.panel h2 { margin: 0; font-size: 20px; color: #ffcc4d; }
.panel .about { margin: 0; color: #d9d8b8; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.panel textarea {
  width: 100%; min-height: 7.5em; max-height: 50vh; resize: vertical; padding: 10px 12px; border-radius: 8px;
  font: 20px/1.5 system-ui, -apple-system, "Segoe UI", sans-serif; color: #0b1220; background: #fdfcf0; border: 2px solid #ebeac5;
}
.panel .row { display: flex; flex-wrap: wrap; gap: 10px; justify-content: flex-end; align-items: center; }
.panel .row .speak { margin-right: auto; }
.speak.on { background: #ff2d55; border-color: #ff2d55; color: #fff; }
.review { position: fixed; inset: 0; z-index: 2147483646; background: #0b1220; display: grid; place-items: center; padding: 16px; overflow-y: auto; }
.card { position: static; width: min(28rem, 100%); padding: 22px 20px 20px; display: flex; flex-direction: column; gap: 14px; }
.card h1 { margin: 0; font-size: 26px; line-height: 1.25; color: #ffcc4d; }
.card p { margin: 0; }
.card label, .notice label { display: flex; flex-direction: column; gap: 6px; font-weight: 700; }
.card input, .notice input {
  font: 20px/1.4 system-ui, -apple-system, "Segoe UI", sans-serif; min-height: 48px; padding: 8px 12px; border-radius: 8px;
  color: #0b1220; background: #fdfcf0; border: 2px solid #ebeac5; width: 100%;
}
.card input:focus-visible, .notice input:focus-visible { outline: 3px solid #7fd4ff; outline-offset: 2px; }
.card .row { display: flex; flex-wrap: wrap; gap: 10px; }
.card .row > * { flex: 1 1 auto; }
.card .error { color: #ffb4a8; font-weight: 700; }
.panel .error { margin: 0; color: #ffb4a8; font-weight: 700; }
.toast { left: 50%; bottom: max(12px, env(safe-area-inset-bottom)); transform: translateX(-50%); width: max-content; max-width: calc(100vw - 24px); text-align: center; padding: 10px 18px; font-weight: 700; }
/* on a phone the toast sits above the buttons, not over them */
@media (max-width: 640px) { .toast { bottom: calc(max(12px, env(safe-area-inset-bottom)) + 60px); } }
.notice {
  left: max(12px, env(safe-area-inset-left)); bottom: max(12px, env(safe-area-inset-bottom)); width: max-content; max-width: min(26rem, calc(100vw - 24px));
  padding: 12px 14px; display: flex; flex-direction: column; gap: 10px;
}
.notice p { margin: 0; font-weight: 700; }
.notice .row { display: flex; flex-wrap: wrap; gap: 10px; }
.notice .row > * { flex: 1 1 auto; }
.notice .error { color: #ffb4a8; }
a.go { display: inline-flex; align-items: center; justify-content: center; min-height: 44px; padding: 6px 16px; border-radius: 8px; font-weight: 700; text-decoration: none; background: #ffcc4d; color: #0b1220; border: 2px solid #ffcc4d; }
a.go:focus-visible { outline: 3px solid #7fd4ff; outline-offset: 2px; }
.card .sent { color: #8ee6a0; font-weight: 700; }
[hidden] { display: none !important; }
`;

const SVG = 'http://www.w3.org/2000/svg';

/** A small bottle with a rolled note in it, drawn with no markup, so no policy stops it. */
function bottleIcon() {
  const svg = document.createElementNS(SVG, 'svg');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('aria-hidden', 'true');
  const shape = (name, attrs) => {
    const el = document.createElementNS(SVG, name);
    for (const [k, v] of Object.entries(attrs)) el.setAttribute(k, v);
    svg.append(el);
  };
  shape('rect', { x: '9.5', y: '1.5', width: '5', height: '3', rx: '1', fill: '#c98a4b' });
  shape('path', { d: 'M10 4.5h4v3.2c2.6 1 4 3 4 5.6V20a2.5 2.5 0 0 1-2.5 2.5h-7A2.5 2.5 0 0 1 6 20v-6.7c0-2.6 1.4-4.6 4-5.6z', fill: '#7fd4ff', 'fill-opacity': '0.35', stroke: '#f8f7dd', 'stroke-width': '1.5' });
  shape('rect', { x: '9', y: '12', width: '6', height: '7', rx: '1', fill: '#f8f7dd', transform: 'rotate(-12 12 15.5)' });
  shape('path', { d: 'M10.4 14.2l3.4-.7M10.7 16l3.4-.7', stroke: '#13203a', 'stroke-width': '0.9' });
  return svg;
}

const make = (tag, props = {}, ...children) => {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === 'class') el.className = v;
    else if (k in el) el[k] = v;
    else el.setAttribute(k, v);
  }
  el.append(...children);
  return el;
};

/**
 * A CSS selector that finds `el` again: from the nearest ancestor with an id only it has (or
 * from <body>), each step a tag, numbered among its kind where it has brothers and sisters.
 */
export function selectorOf(el, doc = document) {
  if (!el || el === doc.documentElement) return 'html';
  const parts = [];
  for (let node = el; node && node.nodeType === 1 && node !== doc.documentElement; node = node.parentElement) {
    if (node.id && doc.querySelectorAll(`#${globalThis.CSS.escape(node.id)}`).length === 1) {
      parts.unshift(`#${globalThis.CSS.escape(node.id)}`);
      break;
    }
    let part = node.localName;
    const kin = node.parentElement ? [...node.parentElement.children].filter((c) => c.localName === node.localName) : [];
    if (kin.length > 1) part += `:nth-of-type(${kin.indexOf(node) + 1})`;
    parts.unshift(part);
  }
  return parts.join(' > ');
}

/** The words a part shows, in one line: what it says, or failing that how it is labelled. */
const wordsOf = (el) => (el.innerText || el.getAttribute?.('aria-label') || el.getAttribute?.('alt') || el.getAttribute?.('title') || el.value || '')
  .replace(/\s+/g, ' ').trim().slice(0, 1000);

/** What a part is, said briefly: the start of its words. */
const describe = (el, whole) => {
  if (whole) return 'The whole page';
  const words = wordsOf(el);
  return words ? `"${words.length > 60 ? `${words.slice(0, 60)}...` : words}"` : 'This part';
};

/** Bytes as a data URL, for a font or picture the screenshot needs inside itself. */
const dataUrl = (blob) => new Promise((resolve, reject) => {
  const reader = new FileReader();
  reader.onload = () => resolve(reader.result);
  reader.onerror = () => reject(reader.error);
  reader.readAsDataURL(blob);
});

/**
 * The @font-face rules of every font the page has loaded, each with its file inside it, for
 * the screenshot: a picture drawn from the page cannot fetch fonts of its own. (Left to
 * itself, modern-screenshot gathers these through a <style> element, which a strict content
 * security policy stops.)
 */
async function fontCss() {
  const loaded = new Set([...document.fonts].filter((f) => f.status === 'loaded').map((f) => f.family.replace(/^["']|["']$/g, '')));
  const faces = [];
  const walk = (rules, href) => {
    for (const rule of rules) {
      if (rule instanceof CSSFontFaceRule) {
        if (loaded.has(rule.style.getPropertyValue('font-family').trim().replace(/^["']|["']$/g, ''))) faces.push([rule, href]);
      } else if (rule.cssRules) walk(rule.cssRules, href);
    }
  };
  for (const sheet of document.styleSheets) {
    try { walk(sheet.cssRules, sheet.href ?? location.href); } catch { /* another site's styles cannot be read */ }
  }
  const css = await Promise.all(faces.map(async ([rule, href]) => {
    let text = rule.cssText;
    for (const [whole, , url] of text.matchAll(/url\((["']?)([^"')]+)\1\)/g)) {
      if (url.startsWith('data:')) continue;
      try {
        const res = await fetch(new URL(url, href));
        if (res.ok) text = text.replace(whole, `url("${await dataUrl(await res.blob())}")`);
      } catch { /* that font is drawn in another */ }
    }
    return text;
  }));
  return css.join('\n');
}

/** The parts of the page on the screen that do not scroll with it (position fixed or sticky), outermost only, leaving out `host`. */
function pinned(host) {
  const found = [];
  for (const el of document.body.querySelectorAll('*')) {
    if (el === host || found.some((outer) => outer.contains(el))) continue;
    const position = getComputedStyle(el).position;
    if (position !== 'fixed' && position !== 'sticky') continue;
    const r = el.getBoundingClientRect();
    if (r.width && r.height && r.bottom > 0 && r.top < innerHeight && r.right > 0 && r.left < innerWidth) found.push(el);
  }
  return found;
}

/**
 * A screenshot of what was on the screen, as a JPEG data URL, with `rect` (where the chosen
 * part was, in the window) outlined. Made in the browser from the page itself
 * (modern-screenshot, served beside this as shot.mjs), leaving out `host`. Null if it cannot be made.
 */
async function shoot(base, host, rect) {
  try {
    const { domToCanvas } = await import(new URL('shot.mjs', base).href);
    const width = innerWidth, height = innerHeight;
    const scale = Math.min(devicePixelRatio || 1, 2, 2400 / width);
    // the page is drawn as big as the window, as far down as it was scrolled, so it shows what was seen
    const font = { cssText: await fontCss() };
    const leaveOut = (node) => node !== host && node.nodeName !== 'NOSCRIPT';
    const page = await domToCanvas(document.documentElement, {
      width, height, scale, timeout: 8000, font, filter: leaveOut,
      backgroundColor: [document.body, document.documentElement].map((el) => getComputedStyle(el).backgroundColor).find((c) => c && !/^(transparent|rgba\(.*,\s*0\))$/.test(c)) ?? '#ffffff',
      features: { restoreScrollPosition: true }
    });
    const ctx = page.getContext('2d');
    // what stays put while the page scrolls (a bar across the top, say) is drawn where it was seen, not where it sits in the page
    for (const el of pinned(host)) {
      const r = el.getBoundingClientRect();
      try {
        const part = await domToCanvas(el, { scale, timeout: 4000, font, filter: leaveOut });
        ctx.drawImage(part, r.left * scale, r.top * scale, r.width * scale, r.height * scale);
      } catch { /* drawn where it sits in the page, then */ }
    }
    if (rect) {
      ctx.lineWidth = 4 * scale;
      ctx.strokeStyle = '#ff2d55';
      ctx.strokeRect((rect.x - 3) * scale, (rect.y - 3) * scale, (rect.width + 6) * scale, (rect.height + 6) * scale);
    }
    return page.toDataURL('image/jpeg', 0.8);
  } catch (err) {
    console.warn('bottle: the screenshot could not be made', err);
    return null;
  }
}

/** The site the page's line names (data-site), where more than one site shares its address; null when it names none. */
let named = null;

/** Asks the service, sending `key` (and the site the line names): path is under the bottle's own address, and a body makes it a POST. */
const asker = (base, key) => (path, body) => fetch(new URL(path, base), {
  method: body === undefined ? 'GET' : 'POST', credentials: 'omit',
  headers: { ...(body === undefined ? {} : { 'content-type': 'application/json' }), ...(key() ? { 'x-bottle-key': key() } : {}), ...(named ? { 'x-bottle-site': named } : {}) },
  ...(body === undefined ? {} : { body: JSON.stringify(body) })
});

/** What the service says `token` is: 'key' (a right one), 'code' (a link's, not used yet), 'wrong', or 'unknown' if it cannot be reached. */
async function lookUp(base, token) {
  try {
    const res = await asker(base, () => token)('check', {});
    if (res.ok) return 'key';
    if (res.status === 409) return 'code';
    return res.status === 403 || res.status === 404 ? 'wrong' : 'unknown';
  } catch {
    return 'unknown';
  }
}

/** Swaps a link's `code` for a key of this browser's own: the key, or null if the link has run out. Throws if the service cannot be reached. */
async function useCode(base, code) {
  const res = await asker(base, () => code)('check', { use: true });
  if (res.ok) return (await res.json()).key ?? null;
  if (res.status === 403 || res.status === 404) return null;
  throw new Error(String(res.status));
}

/** The most a note may carry, as the service takes it (MAX_BYTES in server.mjs): one bigger goes without its screenshot. */
export const MOST = 6 * 1024 * 1024;

/** The most a copy sent as the page closes may be: browsers send no more than 64 KB that way. */
const CLOSING_MOST = 60 * 1024;

/** A name for a note, made before its first try and kept for every try after (`sent`, in server.mjs). */
export const sentId = () => [...crypto.getRandomValues(new Uint8Array(16))].map((b) => b.toString(16).padStart(2, '0')).join('');

/**
 * The notes this browser has sent that the service has not yet said it keeps, under `name` in
 * `storage` (localStorage). A note is kept here before its first try and goes only once the
 * service answers that it has it, so a note is never lost to a dropped connection, the service
 * being down or restarting, a page reloaded or a tab closed mid-send: the next try (on this page
 * a while later, or on the next page of the site opened in this browser) sends it again, under
 * the same `sent`, which the service keeps once. `send(body)` posts it, resolving to the answer.
 *
 * deliver() says what became of one: 'sent'; 'later', kept to try again (no connection, the
 * service busy or not there, the key refused for now); or 'refused', which no try will change
 * (a note with no words), taken out with the service's `error`.
 */
export class Outbox {
  constructor({ storage, name, send }) {
    Object.assign(this, { storage, name, send });
  }

  /** The notes waiting, oldest first. */
  list() {
    try { const kept = JSON.parse(this.storage?.getItem(this.name) ?? '[]'); return Array.isArray(kept) ? kept : []; } catch { return []; }
  }

  /** Saves the list; if the screenshots will not fit, keeps the notes without them. Says whether it was kept. */
  save(list) {
    try {
      if (list.length) this.storage.setItem(this.name, JSON.stringify(list));
      else this.storage.removeItem(this.name);
      return true;
    } catch {
      try { this.storage.setItem(this.name, JSON.stringify(list.map((n) => ({ ...n, body: { ...n.body, shot: null } })))); return true; } catch { return false; }
    }
  }

  /** Keeps a note (a body for POST notes, with its `sent`) to send; gives back what is kept. */
  add(body) {
    const entry = { sent: body.sent, at: new Date().toISOString(), body };
    this.save([...this.list().filter((n) => n.sent !== body.sent), entry]);
    return entry;
  }

  remove(sent) {
    this.save(this.list().filter((n) => n.sent !== sent));
  }

  /** Takes every note waiting in `other` (another name's) into this one, once each, leaving none there. */
  adopt(other) {
    const mine = this.list(), theirs = other.list().filter((n) => !mine.some((m) => m.sent === n.sent));
    if (theirs.length && !this.save([...mine, ...theirs])) return;
    other.save([]);
  }

  /** Puts the note kept as `sent` right after a try changed it (its screenshot left out). */
  update(sent, change) {
    this.save(this.list().map((n) => (n.sent === sent ? change(n) : n)));
  }

  /** Tries to send one note: { result: 'sent' | 'later' | 'refused', status, error }. */
  async deliver(entry) {
    let body = entry.body;
    // too big to be taken: it goes without its screenshot, which is better than not at all
    if (body.shot && JSON.stringify(body).length > MOST - 64 * 1024) {
      body = { ...body, shot: null };
      this.update(entry.sent, (n) => ({ ...n, body }));
    }
    let res;
    try { res = await this.send(body); } catch { return { result: 'later', status: 0 }; }
    if (res.ok) { this.remove(entry.sent); return { result: 'sent', status: res.status }; }
    if (res.status === 413 && body.shot) {
      this.update(entry.sent, (n) => ({ ...n, body: { ...body, shot: null } }));
      return this.deliver({ ...entry, body: { ...body, shot: null } });
    }
    const error = (await res.json().catch(() => null))?.error ?? 'That could not be sent.';
    if (res.status === 400) { this.remove(entry.sent); return { result: 'refused', status: res.status, error }; }
    return { result: 'later', status: res.status, error };
  }

  /** Tries every note waiting, oldest first: how many went, and how many are still waiting. */
  async flush() {
    let sent = 0;
    for (const entry of this.list()) if ((await this.deliver(entry)).result === 'sent') sent++;
    return { sent, waiting: this.list().length };
  }
}

const keep = (store, key) => { try { localStorage.setItem(store, key); } catch { /* kept for this visit only */ } };
const forget = (store) => { try { localStorage.removeItem(store); } catch { /* nothing kept */ } };

/**
 * What to do with the `link` a page was opened from (a code or, from links sent before, a
 * key) and the key this browser `kept`, given `look(token)`, which says what the service makes
 * of one (lookUp). Returns { show, keep, forget, say, offer, runOut }: the key to show the
 * button with, a key to keep, whether to forget the kept one, what to say once it shows, a
 * link's code to offer to switch the button on with, or that the link has run out.
 *
 * A link never takes away a key that works: one that has run out, opened again in a browser
 * already on, leaves it on and says so. A kept key is forgotten only when it is itself refused,
 * and silently when no link came with it, since that browser could be anyone's.
 */
export async function decide({ link, kept, look }) {
  if (link) {
    const found = await look(link);
    if (found === 'key') return { show: link, keep: link, ...(link === kept ? {} : { say: 'The Suggest a change button is on.' }) };
    if (found === 'code' || found === 'wrong') {
      const was = kept && kept !== link ? await look(kept) : found;
      if (was === 'key') return { show: kept, say: found === 'code' ? 'The Suggest a change button is on already.' : 'This link has run out. The Suggest a change button is still on.' };
      const gone = Boolean(kept) && was === 'wrong';
      return found === 'code' ? { offer: link, forget: gone } : { runOut: true, forget: gone };
    }
    // the service cannot be reached just now: as if there were no link
  }
  if (!kept) return {};
  const was = await look(kept);
  return was === 'key' ? { show: kept } : { forget: was === 'wrong' };
}

/**
 * Parts a note can never be about: anything inside an element marked data-bottle-skip (a
 * preview's own bar, say), and the page's own Note buttons (data-bottle-note).
 */
export const SKIP = '[data-bottle-skip], [data-bottle-note]';

/** Is `el` one of the parts a note can never be about? */
export const skipped = (el) => Boolean(el?.closest?.(SKIP));

/**
 * The part of the page a click while choosing is about: the one under the pointer (`at(x, y)`),
 * or the one last outlined. A click no pointer made (Enter or Space on a link or button, or a
 * screen reader's press) has no place on the screen, so it is about the element it was made on.
 * A click on a part that is skipped is about nothing (null), so choosing goes on.
 */
export function pressedPart(event, at, hovered) {
  const part = event.detail === 0 && event.target?.nodeType === 1 ? event.target : at(event.clientX, event.clientY) ?? hovered;
  return skipped(part) ? null : part;
}

/** Does what decide() said about keys, and gives back the plan. */
async function planned(base, store, link, kept) {
  const plan = await decide({ link, kept, look: (token) => lookUp(base, token) });
  if (plan.forget) forget(store);
  if (plan.keep) keep(store, plan.keep);
  return plan;
}

/**
 * Where a note said aloud is written down when the browser cannot (Brave, Firefox): the
 * address of a speech service (POST mono 16-bit samples at 16,000 a second, at most 12
 * seconds; it answers { text }), relative to the bottle's own, or null for none. The service
 * that serves this file writes it in (createBottle's `hear`).
 */
const HEAR = null;

/** Kept once the browser's speech recognition has shown it has no service behind it, so Speak is not offered again. */
const NO_SPEECH = 'bottle-speech-off';

/** Errors that say the browser's speech service is not there at all, not that one go at it failed. */
export const SPEECH_MISSING = new Set(['network', 'service-not-allowed', 'language-not-supported']);

/**
 * The browser's own speech recognition, where it works, or null. Brave has the name but no
 * service behind it (every go ends in a network error), so it has none; nor has a browser
 * whose service has been found missing before (NO_SPEECH).
 */
export function speechHere(scope = globalThis) {
  if (scope.navigator?.brave) return null;
  try { if (scope.localStorage?.getItem(NO_SPEECH)) return null; } catch { /* no storage: try it */ }
  return scope.SpeechRecognition ?? scope.webkitSpeechRecognition ?? null;
}

/** Remembers that this browser's speech service is missing, unless it may only be offline just now. */
export function speechMissing(scope = globalThis) {
  if (scope.navigator?.onLine === false) return;
  try { scope.localStorage?.setItem(NO_SPEECH, '1'); } catch { /* kept for this page only */ }
}

/** Samples a second the speech service takes: mono, 16-bit. */
export const RATE = 16_000;
/** Longer than this, in seconds, and what is said is cut at a pause and that much written down for good. */
export const CUT_AFTER = 7;
/** How far back from the end a cut may be, in seconds: it is made at the quietest moment in that stretch. */
export const CUT_WITHIN = 3;
/** Under this, in seconds, there is nothing yet worth sending. */
const LEAST = 0.4;
/** Quieter than this everywhere (of 32,767), and nothing was said. */
const HUSH = 400;

/** `samples` (floats from -1 to 1) at `from` a second, as 16-bit samples at RATE: each new sample the mean of the old ones it stands for. */
export function downsample(samples, from) {
  const step = from / RATE, out = new Int16Array(Math.floor(samples.length / step));
  for (let i = 0; i < out.length; i++) {
    const a = Math.floor(i * step), b = Math.max(a + 1, Math.floor((i + 1) * step));
    let sum = 0;
    for (let j = a; j < b; j++) sum += samples[j];
    out[i] = Math.max(-32768, Math.min(32767, Math.round((sum / (b - a)) * 32767)));
  }
  return out;
}

/** Where the quietest twentieth of a second is, between samples `from` and `to` of `pcm`: the sample to cut at. */
export function quietest(pcm, from, to) {
  const span = RATE / 20;
  let best = to, least = Infinity;
  for (let at = Math.max(0, from); at + span <= to; at += span / 2) {
    let sum = 0;
    for (let j = at; j < at + span; j++) sum += pcm[j] * pcm[j];
    if (sum < least) { least = sum; best = at + span / 2; }
  }
  return Math.round(best);
}

const joined = (...parts) => parts.map((part) => part.trim()).filter(Boolean).join(' ');

/**
 * What is said, as it is said, for a speech service to write down. add() takes the samples
 * recorded (16-bit, at RATE); step(), called every second or so, sends what has not been
 * written down for good to `send(pcm)`, which resolves to its words. What runs past CUT_AFTER
 * seconds is cut at a pause and written down for good, so no piece sent is ever long and the
 * words so far are quick to come back. `onText(words)` is told every change. finish() sends
 * the rest and resolves to all of it. (The same approach as Pixel Reel's My notes.)
 */
export class Listener {
  constructor({ send, onText = () => {} }) {
    Object.assign(this, { send, onText });
    this.kept = '';     // written down for good
    this.guess = '';    // what the rest is heard as, so far
    this.tail = new Int16Array(0);   // recorded, and not yet written down for good
    this.busy = null;
    this.failed = null;
  }

  add(samples) {
    const longer = new Int16Array(this.tail.length + samples.length);
    longer.set(this.tail);
    longer.set(samples, this.tail.length);
    this.tail = longer;
  }

  get text() { return joined(this.kept, this.guess); }

  /** Sends what there is, unless a piece is still on its way. */
  step() {
    if (this.busy || this.failed || this.tail.length < LEAST * RATE) return this.busy;
    if (this.tail.length > CUT_AFTER * RATE) {
      const cut = quietest(this.tail, this.tail.length - CUT_WITHIN * RATE, this.tail.length);
      const piece = this.tail.slice(0, cut);
      this.tail = this.tail.slice(cut);
      return this.ask(piece, true);
    }
    return this.ask(this.tail, false);
  }

  ask(piece, forGood) {
    const heard = this.tail.length;
    const quiet = !piece.some((sample) => Math.abs(sample) > HUSH);
    this.busy = (quiet ? Promise.resolve('') : this.send(piece)).then((words) => {
      if (forGood) {
        this.kept = joined(this.kept, words);
        this.guess = '';
      } else if (this.tail.length >= heard) this.guess = words;   // still the start of what is waiting
      this.onText(this.text);
    }, (err) => { this.failed = err; }).finally(() => { this.busy = null; });
    return this.busy;
  }

  /** Writes down the rest for good, and resolves to everything said. Rejects if a piece could not be heard. */
  async finish() {
    while (this.busy) await this.busy;
    if (!this.failed && this.tail.length >= 0.15 * RATE) {
      const rest = this.tail;
      this.tail = new Int16Array(0);
      await this.ask(rest, true);
    }
    if (this.failed) throw this.failed;
    this.guess = '';
    return this.text;
  }
}

/** True where a page can record the microphone for a speech service to hear. */
export const canRecord = (scope = globalThis) => Boolean(scope.navigator?.mediaDevices?.getUserMedia && scope.AudioWorkletNode && scope.AudioContext);

/**
 * Starts recording for the speech service at `endpoint`, with the worklet at `worklet`.
 * Resolves to { stop() } once the microphone is on (the browser may ask first); stop()
 * resolves to everything said, and drop() ends it with nothing more sent.
 */
async function recordForService({ onText, endpoint, worklet }) {
  const stream = await navigator.mediaDevices.getUserMedia({ audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true } });
  const context = new AudioContext();
  const end = () => { for (const track of stream.getTracks()) track.stop(); context.close().catch(() => {}); };
  try {
    await context.resume();   // a browser may hold a new one paused, after the wait for the microphone
    await context.audioWorklet.addModule(worklet);
  } catch (err) {
    end();
    throw err;
  }
  const listener = new Listener({
    onText,
    send: async (pcm) => {
      const res = await fetch(endpoint, { method: 'POST', credentials: 'omit', headers: { 'content-type': 'application/octet-stream' }, body: pcm });
      if (!res.ok) throw new Error('not heard');
      return (await res.json()).text ?? '';
    }
  });
  const node = new AudioWorkletNode(context, 'bottle-hear');
  node.port.onmessage = (e) => listener.add(downsample(e.data, context.sampleRate));
  context.createMediaStreamSource(stream).connect(node);
  const ticking = setInterval(() => listener.step(), 1200);
  const halt = () => { clearInterval(ticking); node.port.onmessage = null; end(); };
  return {
    async stop() { halt(); return listener.finish(); },
    drop() { halt(); }
  };
}

/** The address of this site's page for asking for a new link. */
const reviewHref = () => new URL('/review', location.origin).href;

/** A host on the page with a shadow root of its own, styled by CSS. */
function shadowHost() {
  const host = make('div', { 'data-bottle': '' });
  const root = host.attachShadow({ mode: 'open' });
  const sheet = new CSSStyleSheet();
  sheet.replaceSync(CSS);
  root.adoptedStyleSheets = [sheet];
  return { host, root };
}

/**
 * The page's own Note buttons (data-bottle-note), if it has any: then Bottle draws none of its
 * own, and shows the page's (which the page keeps hidden until then) once the button is on.
 */
const ownButtons = () => [...document.querySelectorAll('[data-bottle-note]')];

/** Shows the page's own Note buttons, each starting `press` (while `signal` holds), or gives false if the page has none. */
function useOwnButtons(press, signal) {
  const own = ownButtons();
  for (const el of own) {
    el.hidden = false;
    el.addEventListener('click', (event) => { event.preventDefault(); press(); }, { signal });
  }
  return own.length > 0;
}

/**
 * Shows the button for a browser that holds a key, or was opened from a link: once the service
 * says the key is right, or once the link's button is pressed. A link that has run out says so,
 * with a way to a new one. If the service cannot be reached just now, nothing shows until the
 * next page.
 */
export async function start({ link, kept, base, store, key, fresh, preview = false, site = null, legacy = null }) {
  if (site) named = site;
  // as bottle.js asked before links held codes: its key, fresh from the address or kept
  if (key !== undefined) [link, kept] = fresh ? [key, null] : [null, key];
  const plan = await planned(base, store, link, kept);
  if (plan.show) dock({ key: plan.show, base, store, said: plan.say, legacy: plan.show === kept ? legacy : null });
  else if (plan.offer) notice({ base, store, code: plan.offer });
  else if (plan.runOut) notice({ base, store, code: null });
  else if (preview) await visit({ base, store });
}

/**
 * The button on a site that is a preview (its line has data-preview, and the service has it
 * marked as one), for anyone who opens its pages: the first press asks their name, which gets
 * them a key of their own, kept like any other, and then it is the button as everyone else has
 * it. On any other site, or if the service cannot be reached, nothing shows.
 */
export async function visit({ base, store, site = null }) {
  if (site) named = site;
  const ask = asker(base, () => null);
  const known = await ask('site', {}).then((res) => (res.ok ? res.json() : null)).catch(() => null);
  if (!known?.preview) return;
  const { host, root } = shadowHost();
  const button = make('button', { class: 'bottle', type: 'button', title: 'Suggest a change to this page' }, bottleIcon(), 'Suggest a change');
  const bar = make('div', { class: 'dock' }, button);
  const name = make('input', { type: 'text', name: 'name', autocomplete: 'name', maxLength: 80 });
  const error = make('p', { class: 'error', role: 'alert', hidden: true });
  const next = make('button', { class: 'go', type: 'submit' }, 'Next');
  const cancel = make('button', { type: 'button' }, 'Cancel');
  const card = make('form', { class: 'notice', 'aria-label': 'Your name', hidden: true }, make('label', {}, 'Your name', name), error, make('div', { class: 'row' }, next, cancel));
  const asked = new AbortController();
  const open = () => { bar.hidden = true; card.hidden = false; error.hidden = true; name.focus(); };
  // a page with a Note button of its own has that one, and no other
  const own = useOwnButtons(open, asked.signal);
  root.append(...(own ? [] : [bar]), card);
  document.body.append(host);
  const close = () => { card.hidden = true; bar.hidden = false; (own ? ownButtons()[0] : button).focus(); };
  button.addEventListener('click', open);
  cancel.addEventListener('click', close);
  card.addEventListener('keydown', (event) => { if (event.key === 'Escape') { event.preventDefault(); close(); } });
  card.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (next.disabled) return;
    const said = name.value.trim();
    if (!said) { error.textContent = 'Write your name first.'; error.hidden = false; name.focus(); return; }
    next.disabled = true;
    error.hidden = true;
    try {
      const res = await ask('visit', { name: said });
      const answer = await res.json().catch(() => null);
      if (!res.ok || !answer?.key) throw new Error(res.status === 429 ? 'Try again in a while.' : answer?.error ?? 'That did not work. Try again in a while.');
      keep(store, answer.key);
      asked.abort();
      host.remove();
      dock({ key: answer.key, base, store, pick: true });
    } catch (err) {
      error.textContent = err instanceof TypeError ? 'Check the connection and try again.' : err.message;
      error.hidden = false;
      next.disabled = false;
    }
  });
}

/**
 * The small card a link shows: with a working `code`, a button that switches the note button
 * on (so only a person, not a mail scanner opening the link, uses it up); without one, word
 * that the link has run out, and the way to a new one.
 */
function notice({ base, store, code }) {
  const { host, root } = shadowHost();
  const card = make('div', { class: 'notice', role: 'region', 'aria-label': 'Suggest a change' });
  root.append(card);
  document.body.append(host);
  const close = make('button', { type: 'button' }, code ? 'Not now' : 'Close');
  close.addEventListener('click', () => host.remove());
  const ranOut = () => {
    const again = make('a', { class: 'go', href: reviewHref() }, 'Get a new link');
    card.replaceChildren(make('p', { role: 'status' }, 'This link has run out'), make('div', { class: 'row' }, again, close));
    close.textContent = 'Close';
    again.focus();
  };
  if (!code) { ranOut(); return; }
  const on = make('button', { class: 'go', type: 'button' }, 'Switch on Suggest a change');
  const error = make('p', { class: 'error', role: 'alert', hidden: true });
  on.addEventListener('click', async () => {
    on.disabled = true;
    error.hidden = true;
    try {
      const key = await useCode(base, code);
      if (!key) { ranOut(); return; }
      keep(store, key);
      host.remove();
      dock({ key, base, store, said: 'The Suggest a change button is on.' });
    } catch {
      error.textContent = 'Check the connection and try again.';
      error.hidden = false;
      on.disabled = false;
    }
  });
  card.replaceChildren(make('div', { class: 'row' }, on, close), error);
  on.focus();
}

/** The button itself, and what it opens, for a browser holding `key`; `said` is shown once it is there, and with `pick` it starts choosing a part at once. */
function dock({ key, base, store, said, pick = false, legacy = null }) {
  const send = asker(base, () => key);
  let storage = null;
  try { storage = localStorage; } catch { /* no storage here: a note waits only while the page is open */ }
  const outbox = new Outbox({ storage: storage ?? memoryStorage(), name: `${store}:unsent`, send: (body) => send('notes', body) });
  // the notes left unsent under the name the key was kept by before (see bottle.js) are this key's: they go with these
  if (legacy) outbox.adopt(new Outbox({ storage: outbox.storage, name: `${legacy}:unsent` }));

  const { host, root } = shadowHost();
  const button = make('button', { class: 'bottle', type: 'button', title: 'Suggest a change to this page' }, bottleIcon(), 'Suggest a change');
  const dock = make('div', { class: 'dock' }, button);
  const ring = make('div', { class: 'ring', hidden: true }, make('span'));
  const whole = make('button', { type: 'button' }, 'Whole page');
  const cancelPick = make('button', { type: 'button' }, 'Cancel');
  const banner = make('div', { class: 'banner', hidden: true, role: 'status' }, make('p', {}, `${matchMedia('(pointer: coarse)').matches ? 'Tap' : 'Click'} the part this is about`), whole, cancelPick);
  const about = make('p', { class: 'about' });
  const box = make('textarea', { name: 'note', 'aria-label': 'Your suggestion', placeholder: 'What should change?' });
  const error = make('p', { class: 'error', hidden: true, role: 'alert' });
  const go = make('button', { class: 'go', type: 'submit' }, 'Send');
  const cancelNote = make('button', { type: 'button' }, 'Cancel');
  // Speak: the browser's own speech recognition, or else recording for the speech service, or else no Speak
  let Speech = speechHere();
  const hearAt = HEAR && canRecord() ? { endpoint: new URL(HEAR, base).href, worklet: new URL('hear-worklet.js', base).href } : null;
  const speak = make('button', { class: 'speak', type: 'button', hidden: !Speech && !hearAt, 'aria-pressed': 'false' }, 'Speak');
  const panel = make('form', { class: 'panel', hidden: true, 'aria-label': 'Suggest a change' }, make('h2', {}, 'Suggest a change'), about, box, error, make('div', { class: 'row' }, speak, cancelNote, go));
  const toast = make('div', { class: 'toast', hidden: true, role: 'status' });
  // a page with a Note button of its own has that one, and no other
  const own = useOwnButtons(() => { if (!picking && panel.hidden) startPicking(); });
  root.append(ring, ...(own ? [] : [dock]), banner, panel, toast);
  const focusButton = () => (own ? ownButtons()[0] ?? button : button).focus();
  document.body.append(host);

  let picking = false, hovered = null, chosen = null, shot = null, listening = null, spoken = false;

  const ours = (event) => event.composedPath().includes(host);

  const outline = (el) => {
    hovered = el;
    if (!el) { ring.hidden = true; return; }
    const r = el.getBoundingClientRect();
    Object.assign(ring.style, { left: `${r.left - 3}px`, top: `${r.top - 3}px`, width: `${r.width + 6}px`, height: `${r.height + 6}px` });
    ring.classList.toggle('low', r.top < 32);
    ring.firstChild.textContent = 'this part';
    ring.hidden = false;
  };

  const onMove = (event) => {
    if (ours(event)) return;
    const el = document.elementFromPoint(event.clientX, event.clientY);
    if (skipped(el)) outline(null);
    else if (el && el !== host && el !== hovered) outline(el);
  };
  // while choosing, the page's own buttons and links do nothing: a press only chooses
  const swallow = (event) => {
    if (ours(event)) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    if (event.type === 'pointerdown') onMove(event);
    if (event.type === 'click') choose(pressedPart(event, (x, y) => document.elementFromPoint(x, y), hovered), false);
  };
  const onKey = (event) => {
    if (event.key !== 'Escape') return;
    if (picking) { event.preventDefault(); stopPicking(); } else if (!panel.hidden) { event.preventDefault(); closePanel(); }
  };
  const PRESSES = ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click', 'auxclick', 'dblclick', 'contextmenu'];

  function startPicking() {
    picking = true;
    dock.hidden = true;
    banner.hidden = false;
    addEventListener('pointermove', onMove, true);
    for (const type of PRESSES) addEventListener(type, swallow, true);
    whole.focus();
  }

  function stopPicking({ keepRing = false } = {}) {
    picking = false;
    banner.hidden = true;
    removeEventListener('pointermove', onMove, true);
    for (const type of PRESSES) removeEventListener(type, swallow, true);
    if (!keepRing) { outline(null); dock.hidden = false; focusButton(); }
  }

  function choose(el, isWhole) {
    if (!el || el === host) return;
    stopPicking({ keepRing: true });
    const rect = isWhole ? null : el.getBoundingClientRect();
    chosen = { el, whole: isWhole, rect };
    if (isWhole) outline(null);
    else outline(el);
    // what was on the screen, taken now, before the box to write in covers any of it (the button's own parts are left out)
    shot = shoot(base, host, rect);
    about.textContent = describe(el, isWhole);
    about.title = about.textContent;
    // the box goes where it hides least of that part: above or below it on a phone, beside it on a wide screen
    panel.classList.toggle('up', Boolean(rect) && rect.top + rect.height / 2 > innerHeight / 2);
    panel.classList.toggle('left', Boolean(rect) && rect.left + rect.width / 2 > innerWidth / 2);
    error.hidden = true;
    spoken = false;
    panel.hidden = false;
    box.focus();
  }

  const speakOn = (on) => {
    speak.classList.toggle('on', on);
    speak.textContent = on ? 'Stop' : 'Speak';
    speak.setAttribute('aria-pressed', String(on));
  };
  const cannotHear = (err) => {
    error.textContent = err?.name === 'NotAllowedError' || err === 'not-allowed' ? 'The microphone is not allowed here. Type it instead.' : 'That could not be heard. Type it instead.';
    error.hidden = false;
    box.focus();
  };

  /** Stops listening; with `keep`, once the last words are written into the box. */
  async function stopListening({ keep = true } = {}) {
    const was = listening;
    listening = null;
    speakOn(false);
    if (was) await was.stop(keep);
  }

  // the note said aloud is written into the box as it is heard, where it can be put right before it is sent
  function listen() {
    if (listening) { stopListening(); return; }
    error.hidden = true;
    if (Speech) listenInBrowser(); else if (hearAt) listenThroughService();
  }

  function listenInBrowser() {
    const heard = new Speech();
    heard.lang = document.documentElement.lang || navigator.language || 'en-GB';
    heard.continuous = true;
    heard.interimResults = false;
    heard.onresult = (event) => {
      const words = [...event.results].slice(event.resultIndex).filter((r) => r.isFinal).map((r) => r[0].transcript.trim()).join(' ');
      if (!words) return;
      box.value = `${box.value.trim()} ${words}`.trim();
      spoken = true;
    };
    heard.onerror = (event) => {
      if (event.error === 'aborted' || event.error === 'no-speech') return;
      if (SPEECH_MISSING.has(event.error)) {
        // this browser's own recognition has nothing behind it: from now on the speech service hears it, or there is no Speak
        speechMissing();
        Speech = null;
        if (hearAt) { listening = null; listenThroughService(); return; }
        speak.hidden = true;
        error.textContent = 'This browser cannot hear you. Type it instead.';
        error.hidden = false;
        box.focus();
        return;
      }
      cannotHear(event.error);
    };
    heard.onend = () => { if (listening?.heard === heard) stopListening(); };
    try { heard.start(); } catch { return; }
    listening = { heard, stop: async () => heard.stop() };
    speakOn(true);
  }

  async function listenThroughService() {
    const before = box.value.trim();
    const show = (words) => { box.value = joined(before, words); };
    const mine = { stop: async () => {} };
    listening = mine;
    speakOn(true);
    let recording;
    try {
      recording = await recordForService({ ...hearAt, onText: show });
    } catch (err) {
      if (listening === mine) { listening = null; speakOn(false); }
      cannotHear(err);
      return;
    }
    // pressed Stop (or closed the box) while the microphone was being switched on
    if (listening !== mine) { recording.drop(); return; }
    mine.stop = async (keep) => {
      if (!keep) { recording.drop(); return; }
      speak.disabled = true;
      speak.textContent = 'One moment';
      try {
        const words = await recording.stop();
        show(words);
        if (words) spoken = true;
      } catch (err) {
        cannotHear(err);
      } finally {
        speak.disabled = false;
        speakOn(false);
      }
    };
  }

  function closePanel() {
    stopListening({ keep: false });
    panel.hidden = true;
    chosen = null;
    shot = null;
    outline(null);
    dock.hidden = false;
    focusButton();
  }

  let toastTimer = null;
  const say = (words, ms = 3500) => {
    toast.textContent = words;
    toast.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { toast.hidden = true; }, ms);
  };

  // notes not yet taken are tried again: now, a while later (longer each time, up to ten
  // minutes), as soon as the connection is back, and whenever the page is looked at again
  let flushing = null, retryTimer = null, wait = 15_000;
  const flush = () => {
    if (flushing) return flushing;
    clearTimeout(retryTimer);
    flushing = (async () => {
      if (!outbox.list().length) return;
      const { sent, waiting } = await outbox.flush();
      if (sent) say(sent === 1 ? 'Your suggestion has been sent. Thank you.' : `Your ${sent} suggestions have been sent. Thank you.`);
      if (waiting) {
        retryTimer = setTimeout(flush, wait);
        wait = Math.min(wait * 2, 600_000);
      } else wait = 15_000;
    })().finally(() => { flushing = null; });
    return flushing;
  };
  addEventListener('online', () => { wait = 15_000; flush(); });
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') flush(); });
  // a tab closed with a note still waiting sends a copy of its words as it goes (browsers send
  // only a little that way, so without the screenshot); the service keeps it once, and the
  // whole note, screenshot and all, follows from the next page of the site opened here
  addEventListener('pagehide', () => {
    for (const { body } of outbox.list()) {
      const words = JSON.stringify({ ...body, shot: null });
      if (words.length > CLOSING_MOST) continue;
      try {
        fetch(new URL('notes', base), { method: 'POST', keepalive: true, credentials: 'omit', headers: { 'content-type': 'application/json', 'x-bottle-key': key, ...(named ? { 'x-bottle-site': named } : {}) }, body: words }).catch(() => {});
      } catch { /* the next page sends it */ }
    }
  });

  async function submit(event) {
    event.preventDefault();
    if (!chosen || go.disabled) return;
    go.disabled = true;
    await stopListening();
    go.disabled = false;
    if (!box.value.trim()) { error.textContent = 'Write what should change first.'; error.hidden = false; box.focus(); return; }
    go.disabled = true;
    go.textContent = 'Sending...';
    error.hidden = true;
    const { el, whole: isWhole, rect } = chosen;
    const body = {
      note: box.value,
      spoken,
      page: { url: location.href, title: document.title },
      target: { whole: isWhole, selector: isWhole ? 'html' : selectorOf(el), tag: el.localName, text: isWhole ? '' : wordsOf(el), rect: rect && { x: rect.x, y: rect.y, width: rect.width, height: rect.height } },
      viewport: { width: innerWidth, height: innerHeight, scale: devicePixelRatio, scrollX, scrollY },
      browser: navigator.userAgent,
      settings: { ...document.documentElement.dataset },
      shot: await shot,
      sent: sentId()
    };
    // kept in this browser before it is sent, so nothing that happens now can lose it
    const entry = outbox.add(body);
    try {
      const { result, error: why } = await outbox.deliver(entry);
      if (result === 'refused') {
        error.textContent = why;
        error.hidden = false;
        return;
      }
      box.value = '';
      closePanel();
      if (result === 'sent') { say('Sent. Thank you.'); return; }
      say('Not sent yet. It is kept here, and goes by itself as soon as it can.', 8000);
      wait = 15_000;
      retryTimer = setTimeout(flush, wait);
    } finally {
      go.disabled = false;
      go.textContent = 'Send';
    }
  }

  button.addEventListener('click', startPicking);
  whole.addEventListener('click', () => choose(document.documentElement, true));
  cancelPick.addEventListener('click', () => stopPicking());
  cancelNote.addEventListener('click', closePanel);
  speak.addEventListener('click', listen);
  panel.addEventListener('submit', submit);
  addEventListener('keydown', onKey, true);
  if (said) say(said);
  if (pick) startPicking();
  // notes left before, on this page or another of the site, that have not gone yet
  flush();
}

/** A stand-in for localStorage where there is none (a private window that refuses it): the notes wait only while the page is open. */
function memoryStorage() {
  const items = new Map();
  return { getItem: (k) => items.get(k) ?? null, setItem: (k, v) => items.set(k, String(v)), removeItem: (k) => items.delete(k) };
}

/**
 * The site's /review page, named for the site: whoever is on the site's list gives their email
 * and is sent a link that switches the button on; anyone else is told the same, and nothing
 * more. A browser that holds a key already is told the button is on, and can turn it off; one
 * opened from a link is offered its button here too, or told the link has run out.
 */
export async function review({ link = null, kept = null, base, store, key, site = null }) {
  if (site) named = site;
  if (key !== undefined) kept = key;
  const { host, root } = shadowHost();
  const card = make('form', { class: 'card', 'aria-label': 'Review this website' });
  root.append(make('div', { class: 'review' }, card));
  document.body.append(host);
  let submit = null;
  card.addEventListener('submit', (event) => { event.preventDefault(); submit?.(); });
  const ask = asker(base, () => null);
  const [plan, name] = await Promise.all([
    planned(base, store, link, kept),
    ask('site', {}).then((res) => (res.ok ? res.json() : null)).then((site) => site?.name ?? null).catch(() => null)
  ]);
  const heading = () => make('h1', {}, name ? `Review ${name}` : 'Review this website');
  if (name) card.setAttribute('aria-label', `Review ${name}`);

  const on = (key) => {
    submit = null;
    const off = make('button', { type: 'button' }, 'Turn off');
    off.addEventListener('click', () => { forget(store); asking(null); });
    const go = make('a', { class: 'go', href: '/' }, 'Go to the website');
    // Add to Claude: suggestions by talking to Claude, through a connector of their own (mcp.mjs), added in one press there
    const claude = make('button', { type: 'button' }, 'Add to Claude');
    const error = make('p', { class: 'error', hidden: true, role: 'alert' });
    claude.addEventListener('click', async () => {
      if (claude.disabled) return;
      claude.disabled = true;
      error.hidden = true;
      try {
        const res = await asker(base, () => key)('claude', {});
        const answer = await res.json().catch(() => null);
        if (!res.ok || !answer?.add) throw new Error(res.status === 429 ? 'Try again in a while.' : 'That did not work. Try again in a while.');
        location.assign(answer.add);
      } catch (err) {
        error.textContent = err instanceof TypeError ? 'Check the connection and try again.' : err.message;
        error.hidden = false;
        claude.disabled = false;
      }
    });
    card.replaceChildren(make('h1', {}, 'The Suggest a change button is on'), error, make('div', { class: 'row' }, go), make('div', { class: 'row' }, claude, off));
    go.focus();
  };

  const offer = (code) => {
    const go = make('button', { class: 'go', type: 'submit' }, 'Switch on Suggest a change');
    const error = make('p', { class: 'error', hidden: true, role: 'alert' });
    submit = async () => {
      if (go.disabled) return;
      go.disabled = true;
      try {
        const key = await useCode(base, code);
        if (!key) { asking('This link has run out.'); return; }
        keep(store, key);
        on(key);
      } catch {
        error.textContent = 'Check the connection and try again.';
        error.hidden = false;
        go.disabled = false;
      }
    };
    card.replaceChildren(heading(), error, go);
    go.focus();
  };

  /** Sends a link to `email`: true once the service has taken it, or a message saying why not. */
  const sendLink = async (email) => {
    try {
      const res = await ask('signin', { email });
      if (res.status === 202) return true;
      return res.status === 429 ? 'Try again in a while.' : (await res.json().catch(() => null))?.error ?? 'That did not work. Try again in a while.';
    } catch {
      return 'Check the connection and try again.';
    }
  };

  const sent = (address) => {
    const again = make('button', { type: 'submit' }, 'Send again');
    const status = make('p', { role: 'status' }, 'If that address is on the list, a link is on its way. It works once, for 30 minutes.');
    const said = make('p', { class: 'sent', hidden: true, role: 'status' });
    submit = async () => {
      if (again.disabled) return;
      again.disabled = true;
      said.hidden = true;
      const done = await sendLink(address);
      said.className = done === true ? 'sent' : 'error';
      said.textContent = done === true ? 'Sent again.' : done;
      said.hidden = false;
      again.disabled = false;
    };
    card.replaceChildren(make('h1', {}, 'Check your email'), status, said, again);
    again.focus();
  };

  const asking = (problem) => {
    const email = make('input', { type: 'email', name: 'email', autocomplete: 'email', required: true, inputMode: 'email', maxLength: 254 });
    const error = make('p', { class: 'error', hidden: !problem, role: 'alert' }, problem ?? '');
    const go = make('button', { class: 'go', type: 'submit' }, 'Send me a link');
    submit = async () => {
      if (go.disabled) return;
      go.disabled = true;
      error.hidden = true;
      const done = await sendLink(email.value);
      if (done === true) { sent(email.value); return; }
      error.textContent = done;
      error.hidden = false;
      go.disabled = false;
    };
    card.replaceChildren(heading(), error, make('label', {}, 'Email', email), go);
    email.focus();
  };

  if (plan.show) on(plan.show);
  else if (plan.offer) offer(plan.offer);
  else asking(plan.runOut ? 'This link has run out.' : null);
}

/**
 * The site's /suggest page, named for the site: whoever was told the site's word gives it, and
 * their name, once, and the button is on in this browser for a year (their suggestions wait
 * until whoever looks after the site approves them, once). A browser that holds a key already
 * is told the button is on, and can turn it off. The word is in any case; a wrong one says so,
 * and too many are turned away for a while.
 *
 * The word is the one way in yet. Another (a code sent to their phone, say) would be one more
 * step here, asking the service to join `by` it, as this asks to join by the word.
 */
export async function suggest({ link = null, kept = null, base, store, site = null }) {
  if (site) named = site;
  const { host, root } = shadowHost();
  const card = make('form', { class: 'card', 'aria-label': 'Suggest a change' });
  root.append(make('div', { class: 'review' }, card));
  document.body.append(host);
  let submit = null;
  card.addEventListener('submit', (event) => { event.preventDefault(); submit?.(); });
  const ask = asker(base, () => null);
  const [plan, known] = await Promise.all([
    planned(base, store, link, kept),
    ask('site', {}).then((res) => (res.ok ? res.json() : null)).catch(() => null)
  ]);
  const title = known?.name ? `Suggest a change to ${known.name}` : 'Suggest a change';
  card.setAttribute('aria-label', title);

  const on = () => {
    submit = null;
    const off = make('button', { type: 'button' }, 'Turn off');
    off.addEventListener('click', () => { forget(store); asking(); });
    const go = make('a', { class: 'go', href: '/' }, 'Go to the website');
    card.replaceChildren(make('h1', {}, 'The Suggest a change button is on'), make('div', { class: 'row' }, go, off));
    go.focus();
  };

  const asking = () => {
    if (!known?.word) {
      card.replaceChildren(make('h1', {}, title), make('p', { class: 'error', role: 'alert' }, known ? 'This website takes no word.' : 'Check the connection and try again.'));
      return;
    }
    const word = make('input', { type: 'text', name: 'word', autocomplete: 'off', autocapitalize: 'none', spellcheck: false, required: true, maxLength: 40 });
    const name = make('input', { type: 'text', name: 'name', autocomplete: 'name', required: true, maxLength: 80 });
    const error = make('p', { class: 'error', hidden: true, role: 'alert' });
    const go = make('button', { class: 'go', type: 'submit' }, 'Switch on Suggest a change');
    const fail = (message, field) => { error.textContent = message; error.hidden = false; go.disabled = false; field?.focus(); };
    submit = async () => {
      if (go.disabled) return;
      if (!word.value.trim()) { fail('Write the word first.', word); return; }
      if (!name.value.trim()) { fail('Write your name first.', name); return; }
      go.disabled = true;
      error.hidden = true;
      try {
        const res = await ask('join', { by: 'word', word: word.value, name: name.value });
        const answer = await res.json().catch(() => null);
        if (res.status === 403) { fail('That is not the word.', word); word.select(); return; }
        if (!res.ok || !answer?.key) { fail(res.status === 429 ? answer?.error ?? 'Try again in a while.' : answer?.error ?? 'That did not work. Try again in a while.'); return; }
        keep(store, answer.key);
        on();
      } catch {
        fail('Check the connection and try again.');
      }
    };
    card.replaceChildren(make('h1', {}, title), error, make('label', {}, 'The word', word), make('label', {}, 'Your name', name), go);
    word.focus();
  };

  if (plan.show) on();
  else asking();
}
