// Where the bottle keeps everything when it runs on its own (main.mjs): a folder on this
// machine. Keys are paths such as "bottles/<id>/note.json"; values are bytes. Any store with
// the same put, get, folders and remove will do instead (one in a bucket, say).
import { mkdir, readdir, readFile, rename, rm, writeFile } from 'node:fs/promises';
import { dirname, join, resolve, sep } from 'node:path';

const KEY = /^[A-Za-z0-9_-][A-Za-z0-9_.-]*(\/[A-Za-z0-9_-][A-Za-z0-9_.-]*)*$/;

/** Checks a key is a plain relative path, with no way out of the store. */
export function checkKey(key) {
  if (typeof key !== 'string' || !KEY.test(key) || key.split('/').some((part) => part === '..' || part === '.')) {
    throw new Error(`"${key}" is not a key the store takes`);
  }
  return key;
}

/** A store in a folder. */
export class FolderStore {
  constructor(root) {
    this.root = resolve(root);
  }

  toString() {
    return this.root;
  }

  path(key) {
    const file = join(this.root, checkKey(key));
    if (!file.startsWith(this.root + sep)) throw new Error(`"${key}" is outside the store`);
    return file;
  }

  /** Saves `data` (bytes or text) under `key`, all at once: a reader never sees half a file. */
  async put(key, data) {
    const file = this.path(key), part = `${file}.${process.pid}.${Date.now()}.part`;
    await mkdir(dirname(file), { recursive: true });
    await writeFile(part, data);
    await rename(part, file);
  }

  /** The bytes saved under `key`, or null if there are none. */
  async get(key) {
    try {
      return await readFile(this.path(key));
    } catch (err) {
      if (err.code === 'ENOENT' || err.code === 'EISDIR' || err.code === 'ENOTDIR') return null;
      throw err;
    }
  }

  /** The folders directly under `prefix`, such as every note's id under "bottles". */
  async folders(prefix) {
    try {
      return (await readdir(this.path(prefix), { withFileTypes: true })).filter((e) => e.isDirectory()).map((e) => e.name);
    } catch (err) {
      if (err.code === 'ENOENT' || err.code === 'ENOTDIR') return [];
      throw err;
    }
  }

  /** Deletes `prefix` and everything under it. */
  async remove(prefix) {
    await rm(this.path(prefix), { recursive: true, force: true, maxRetries: 10, retryDelay: 20 });
  }
}
