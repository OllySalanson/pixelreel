#!/usr/bin/env node
// Starts Message in a Bottle on its own (main.mjs), from its environment. A plain script, so a
// host that loads its app with require() (Phusion Passenger, as cPanel's Node.js apps do) can
// start it as well as `node start.cjs` or the bottle-service command.
import('./main.mjs').then((service) => service.start());
