// Message in a Bottle on its own: the endpoint as a whole web service, keeping everything in a
// folder, for a host that runs Node and nothing else of ours (a cPanel Node.js app, a small
// server, a container), started by start.cjs. Everything it needs is set in its environment
// (README.md, "Running it on its own"). A Node server of your own can mount the endpoint
// instead: see createBottle in server.mjs.
import { createServer } from 'node:http';
import { resend } from './mail.mjs';
import { createBottle } from './server.mjs';
import { FolderStore } from './store.mjs';

const list = (value) => String(value ?? '').split(',').map((s) => s.trim()).filter(Boolean);
const trimmed = (value) => String(value ?? '').trim();

/** Who is asking, behind `hops` proxies: the address the nearest one was given, else the connection's. */
export function callerOf(req, hops) {
  const chain = hops > 0 ? String(req.headers['x-forwarded-for'] ?? '').split(',').map((a) => a.trim()).filter(Boolean) : [];
  return chain.at(-hops) ?? chain[0] ?? req.socket.remoteAddress ?? 'unknown';
}

/** The service's settings, from an environment such as process.env. */
export function settingsFrom(env) {
  const replyTo = trimmed(env.BOTTLE_REPLY_TO);
  return {
    port: Number(env.PORT || env.BOTTLE_PORT) || 8790,
    data: trimmed(env.BOTTLE_DATA) || 'data',
    origins: list(env.BOTTLE_ORIGINS).map((o) => o.replace(/\/$/, '')),
    home: { id: trimmed(env.BOTTLE_HOME_ID) || 'home', name: trimmed(env.BOTTLE_HOME_NAME) || 'This site' },
    owner: { id: trimmed(env.BOTTLE_OWNER_ID) || 'owner', name: trimmed(env.BOTTLE_OWNER_NAME) || 'Owner' },
    key: trimmed(env.BOTTLE_KEY),
    reader: trimmed(env.BOTTLE_READER),
    prefix: (trimmed(env.BOTTLE_PREFIX) || '/bottle').replace(/\/$/, ''),
    review: trimmed(env.BOTTLE_REVIEW) || null,
    hear: trimmed(env.BOTTLE_HEAR) || null,
    from: trimmed(env.BOTTLE_FROM),
    replyTo,
    notify: trimmed(env.BOTTLE_NOTIFY) || replyTo,
    hook: trimmed(env.BOTTLE_RESEND_WEBHOOK_SECRET),
    resendKey: trimmed(env.BOTTLE_RESEND_KEY),
    mailFrom: trimmed(env.BOTTLE_MAIL_FROM),
    trustProxy: Math.max(0, Math.floor(Number(env.BOTTLE_TRUST_PROXY)) || 0)
  };
}

/**
 * The web service: the endpoint under `prefix`, and `/health` (also under the prefix, for a host
 * that hands the service only the addresses under it). `store` and `mail` may be given, as tests
 * do; otherwise a FolderStore in `data`, and Resend when its key and sending address are set.
 * Answers { server, bottle }; server.listen() starts it.
 */
export function createService(settings, { store = new FolderStore(settings.data), mail = null, log = () => {}, every } = {}) {
  const { resendKey, mailFrom } = settings;
  const sender = mail ?? (resendKey && mailFrom ? resend({ key: resendKey, from: mailFrom, log }) : null);
  if (!sender && (resendKey || mailFrom)) log(`No email is sent: ${resendKey ? 'BOTTLE_MAIL_FROM' : 'BOTTLE_RESEND_KEY'} is not set, so each one is kept in the outbox`);
  const bottle = createBottle({
    store, key: settings.key, reader: settings.reader, origins: settings.origins, home: settings.home, owner: settings.owner,
    prefix: settings.prefix, review: settings.review, hear: settings.hear, mail: sender, from: settings.from, replyTo: settings.replyTo,
    notify: settings.notify, hook: settings.hook, caller: (req) => callerOf(req, settings.trustProxy), log, ...(every === undefined ? {} : { every })
  });
  const health = new Set(['/health', `${settings.prefix}/health`]);
  const server = createServer(async (req, res) => {
    try {
      const path = new URL(req.url, 'http://localhost').pathname;
      if (health.has(path) && (req.method === 'GET' || req.method === 'HEAD')) {
        res.writeHead(200, { 'content-type': 'text/plain; charset=utf-8', 'cache-control': 'no-store', 'x-robots-tag': 'noindex' }).end('ok');
        return;
      }
      if (await bottle.handle(req, res)) return;
      res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8', 'x-robots-tag': 'noindex' }).end('There is nothing here.');
    } catch (err) {
      log(`bottle: ${err.stack ?? err}`);
      if (!res.headersSent) res.writeHead(500, { 'content-type': 'text/plain; charset=utf-8' }).end('Something went wrong.');
    }
  });
  return { server, bottle, mailing: Boolean(sender) };
}

/** Starts the service from process.env, saying what it is doing on stdout. */
export function start(env = process.env, log = (line) => console.log(line)) {
  const settings = settingsFrom(env);
  const { server, bottle, mailing } = createService(settings, { log });
  if (!settings.key && !settings.reader) log('BOTTLE_KEY and BOTTLE_READER are not set: nobody can add a site or read the notes');
  if (!settings.origins.length) log('BOTTLE_ORIGINS is not set: the home site has no address, so the owner\'s key works on no page');
  server.listen(settings.port, () => {
    log(`Message in a Bottle is at :${settings.port}${settings.prefix}, keeping everything in ${resolveData(settings.data)}, ${mailing ? 'sending email through Resend' : 'keeping its emails in the outbox'}`);
  });
  const stop = () => server.close(() => bottle.idle().then(() => process.exit(0)));
  process.once('SIGTERM', stop);
  process.once('SIGINT', stop);
  return server;
}

const resolveData = (data) => new FolderStore(data).toString();
