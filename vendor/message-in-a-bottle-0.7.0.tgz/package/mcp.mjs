// Message in a Bottle in Claude: a connector (a remote MCP server, over Streamable HTTP with
// plain JSON answers and no session) for one person on one site's list, at
// <prefix>/mcp/<key>, where the key is one of theirs, made for it (Add to Claude). It has one
// tool, suggest_change, which puts a suggestion in that site's queue exactly as the button
// does, marked as sent from Claude. It can change nothing and read nothing.
// Written by hand, so the package needs nothing more: initialize, ping, tools/list, tools/call.

/** The protocol versions this answers in, newest first. */
export const PROTOCOLS = ['2025-06-18', '2025-03-26', '2024-11-05'];

/** The most a request may carry: a suggestion is a few hundred words. */
export const MCP_MAX_BYTES = 64 * 1024;

const rpc = (id, result) => ({ jsonrpc: '2.0', id, result });
const rpcError = (id, code, message) => ({ jsonrpc: '2.0', id, error: { code, message } });

/** The name a person's connector goes by in Claude. */
export const connectorName = (site) => `${site.name}: Suggest a change`;

/** A link that opens Claude's own box for adding a connector, with this one filled in: one press of Add, and it is there. */
export const addToClaude = (site, address) =>
  `https://claude.ai/customize/connectors?modal=add-custom-connector&connectorName=${encodeURIComponent(connectorName(site))}&connectorUrl=${encodeURIComponent(address)}`;

/** What Claude is told about the connector, for this person on this site. */
export function instructionsFor({ site, person, owner }) {
  return `This connects ${person.name} to Message in a Bottle for ${site.name}, the website ${owner} is making for them. `
    + `Whenever ${person.name} wants to tell ${owner} something about the website (a change, something to add or take away, a correction, `
    + `how they would like to be contacted, or any message for ${owner}), send it with suggest_change, in their own words, once they have said it. `
    + 'It goes into the queue of suggestions for the site, which is all it can do: it changes nothing on the site itself, and it cannot read anything back.';
}

/** The one tool, described for this person on this site. */
export function toolsFor({ site, person, owner }) {
  return [{
    name: 'suggest_change',
    title: 'Suggest a change',
    description: `Sends a suggestion or a message from ${person.name} to ${owner}, who is making the ${site.name} website. `
      + 'Use it for anything they want changed, added or taken away, and for any message for '
      + `${owner} (for example how they would like to be contacted). Put what they said in "change", in their words, with enough to act on. `
      + 'If it is about one page, name it in "page". It only sends: nothing on the site changes until a person has looked at it.',
    inputSchema: {
      type: 'object',
      properties: {
        change: { type: 'string', description: 'What should change, or the message, in their words.' },
        page: { type: 'string', description: 'The page it is about, if they said: its address, or its name such as "Parties". Leave it out for the whole site.' }
      },
      required: ['change'],
      additionalProperties: false
    },
    annotations: { title: 'Suggest a change', readOnlyHint: false, destructiveHint: false, idempotentHint: false, openWorldHint: false }
  }];
}

/**
 * Answers one JSON-RPC message (or null for a notification, which has no answer). `who` is
 * { site, person } and `owner` the name of whoever makes the sites; `suggest({ change, page })`
 * keeps a suggestion and resolves to a sentence saying where it went, or throws an Error whose
 * message is for Claude to pass on.
 */
export async function answer(message, { who, owner, suggest, version }) {
  if (!message || typeof message !== 'object' || message.jsonrpc !== '2.0' || typeof message.method !== 'string') {
    return rpcError(message?.id ?? null, -32600, 'Not a JSON-RPC 2.0 request.');
  }
  const { id, method, params } = message;
  if (id === undefined || id === null) return null;   // a notification, such as notifications/initialized
  const about = { ...who, owner };
  switch (method) {
    case 'initialize': {
      const asked = params?.protocolVersion;
      return rpc(id, {
        protocolVersion: PROTOCOLS.includes(asked) ? asked : PROTOCOLS[0],
        capabilities: { tools: { listChanged: false } },
        serverInfo: { name: 'message-in-a-bottle', title: `Message in a Bottle: ${who.site.name}`, version },
        instructions: instructionsFor(about)
      });
    }
    case 'ping':
      return rpc(id, {});
    case 'tools/list':
      return rpc(id, { tools: toolsFor(about) });
    case 'tools/call': {
      if (params?.name !== 'suggest_change') return rpcError(id, -32602, `There is no tool called ${params?.name}.`);
      const args = params.arguments ?? {};
      try {
        const said = await suggest({ change: typeof args.change === 'string' ? args.change : '', page: typeof args.page === 'string' ? args.page : '' });
        return rpc(id, { content: [{ type: 'text', text: said }], isError: false });
      } catch (err) {
        return rpc(id, { content: [{ type: 'text', text: err.message }], isError: true });
      }
    }
    default:
      return rpcError(id, -32601, `${method} is not something this connector does.`);
  }
}

/** Answers a whole request body: one message or a list of them. Gives the answer to send, or null for none (202). */
export async function answerAll(body, context) {
  if (Array.isArray(body)) {
    const answers = (await Promise.all(body.map((m) => answer(m, context)))).filter(Boolean);
    return answers.length ? answers : null;
  }
  return answer(body, context);
}
